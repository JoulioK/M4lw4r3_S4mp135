<?php
include_once '../includes/db.php';
session_start();

  if($_SESSION['logged']=="true")
  {
    header("Location: dashboard.php");
    die();
  }




 ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.9/css/all.css" integrity="sha384-5SOiIsAziJl6AWe0HWRKTXlfcSHKmYV4RBF18PPJ173Kzn7jzMyFuTtk8JA7QQG1" crossorigin="anonymous">
        <!-- CSS  -->


  </head>
  <body>

    <div class="container">
      <div class="row">
        <div class="col-sm-5 mx-auto">
          <form action="brain.php" style="background-color: #ffffff;
    margin-top: 12rem;
	1px 1px 15px rgba(0, 0, 0, 0.2);
    padding: 1rem;" method="post">
            <div class="form-group">
                <label for="disabledSelect">Login</label>
             <input type="text"  class="form-control" name="login">
           </div>
              <div class="form-group">
                  <label for="disabledSelect">Password</label>
               <input type="password"  class="form-control" name="password" >
             </div>
              <button type="submit" class="btn btn-success login-button">Submit</button>
          </form>
        </div>
      </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  </body>
</html>
