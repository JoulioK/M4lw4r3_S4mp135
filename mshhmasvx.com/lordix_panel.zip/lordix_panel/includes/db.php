<?php
error_reporting(0);
try
{
	$config = require_once('config.php');
	$pdo = new PDO("mysql:host=".$config['host'].";dbname=".$config['db'],$config['user'],$config['password']);
	$pdo->SetAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	exit($e->getMessage());
}
?>
