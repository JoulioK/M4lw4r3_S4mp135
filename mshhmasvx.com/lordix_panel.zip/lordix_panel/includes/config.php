<?php

return [
	"host" => "localhost",
	"db" => "lordix",
	"user" => "administrator",
	"password" => ""
];


?>
