<?php
error_reporting(0);

define(KEY, "3sc3RLrpd17");

function decrypt($encrypted){
    $method = 'aes-256-cbc';

    $encrypted = str_replace("~", "+", $encrypted);
    $password = substr(hash('sha256',  KEY ,true), 0, 32);

    $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);


    $decrypted = openssl_decrypt(base64_decode($encrypted), $method, $password, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}
function encrypt($decrypted){
    $method = 'aes-256-cbc';

    $password = substr(hash('sha256', KEY , true), 0, 32);

    $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);


    $encrypted = base64_encode(openssl_encrypt($decrypted, $method, $password, OPENSSL_RAW_DATA, $iv));

    $encrypted = str_replace("+", "~", $encrypted);
    return $encrypted;
}
