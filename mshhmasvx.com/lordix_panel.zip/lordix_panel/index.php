<?php
header("HTTP/1.1 404 Not Found");
	include_once("pages/404.php");
	die();
?>