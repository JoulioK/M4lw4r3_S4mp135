		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><?php echo $_GET['title']; ?></h4>
                    </div>
                </div>

				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							<div class="row row-in">
								<div class="ibox-content">
								<?php
									  $id = $_GET['id'];

									  $stmt = $db->select('SELECT log_id, log FROM logs WHERE log_id = ?', array($id), array('%d'));

									  while($log = $stmt->fetch_array())
									  {
									   echo urldecode($log['log']);
									  }
								?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>