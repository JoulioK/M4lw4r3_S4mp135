<?php
	$json_data = array(
		array( 'db' => 'pc_name', 'dt' => 0 ),
		array( 'db' => 'time',  'dt' => 1 ),
		array( 'db' => 'screen',   'dt' => 2 ),
		);
	$where = base64_encode("hwid='".$_GET['id']."'");
	$str = urlencode(serialize($json_data));
?>
		<!-- Popup CSS -->
		<link href="plugins/blueimp/css/blueimp-gallery.min.css" rel="stylesheet">
		
		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><?php echo $_GET['title']; ?></h4>
						<h5>Important: You can see just last 10 screenshots.</h5>
                    </div>
                </div>

				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							<div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-Screenshots" cellspacing="0" width="100%">
									
									<?php
									echo '
									<thead>
									<tr>
									';
									echo '

									<th>Machine Name</th>
									<th>Local Time</th>
									<th>Screenshot</th>
									</tr>
									</thead>
									';
									
									?>
                                </table>
							</div>
						</div>
						<div id="blueimp-gallery" class="blueimp-gallery">
							<div class="slides"></div>
							<h3 class="title"></h3>
							<a class="prev">‹</a>
							<a class="next">›</a>
							<a class="close">×</a>
							<a class="play-pause"></a>
							<ol class="indicator"></ol>
						</div>
					</div>
				</div>
			</div>
		</div>
		
    <script src="plugins/blueimp/jquery.blueimp-gallery.min.js"></script>
	
	<script>
		$(document).ready(function() {
			$('.dataTables-Screenshots').dataTable({
				"order": [[ 1, "desc" ]],
				"processing": true,
				"serverSide": true,
				"ajax": "scripts/process.php?table=screens&primary=screen_id&clmns=<?php echo $str; ?>&where=<?php echo $where; ?>",
				"createdRow": function ( row, data, index ) {
					var imagelink = '<div  style="height: 120px;"><a href="files/<?php echo $_GET['id']; ?>/'+data[2]+'" title="'+data[0]+' - '+data[1]+'" data-gallery="" ><img src="files/<?php echo $_GET['id']; ?>/'+data[2]+'" style="max-height: 100%; max-width: 100%"></a></div>';
					$('td', row).eq(2).html(imagelink);
				},
				"render": function (data) {
                           return '<img src="' +data+ '" />';
                       }
            });
		});
    </script>