<?php
	if(file_exists('config.php')){
		echo "You already created config.php file. Please edit config.php file for changes.";
		exit;
	}
	$errorMessage = "";
	if(!empty($_POST)){
		$mysql_host = $_POST['mysql_host'];
		$mysql_username = $_POST['mysql_username'];
		$mysql_password = $_POST['mysql_password'];
		$mysql_database = $_POST['mysql_db'];
		
		$username = $_POST['Username'];
		$password = $_POST['Password'];
		
		file_put_contents('config.php', '<?php
	$mysql_host = \''.$mysql_host.'\';
	$mysql_database = \''.$mysql_database.'\';
	$mysql_user = \''.$mysql_username.'\';
	$mysql_password = \''.$mysql_password.'\';
	
	$dbb = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . \' Invalid connect: \' . mysqli_error());
	$dbb->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
	$result = $dbb->query("select * from account order by id desc limit 1");
	while ($row = $result->fetch_assoc()) {
		$username = $row[\'username\'];
		$password = $row[\'password\'];
	}
	$dbb->close();
	?>');
	
	$conn = new mysqli($mysql_host, $mysql_username, $mysql_password) or die(__LINE__ . ' Invalid connect: ' . mysqli_error());
	$conn->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$conn->query("CREATE TABLE if not exists account(id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), password VARCHAR(50) NOT NULL)");
	
	$stmt = $conn->prepare("insert into account(username, password) values(?,?)");
	$stmt->bind_param("ss", $username, $password);
	$stmt->execute();
	
	$conn->close();
	
		$errorMessage = "Your settings have been changed.";
	}
?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Web Panel Setup</title>

		<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
		<link rel="manifest" href="favicon/manifest.json">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
		<meta name="theme-color" content="#ffffff">
		
		<!-- Bootstrap Core CSS -->
		<link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
		<link href="plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">  
		<!-- animation CSS -->
		<link href="css/animate.css" rel="stylesheet">
		<script src="plugins/sweetalert/dist/sweetalert.min.js"></script>
		<link rel="stylesheet" type="text/css" href="plugins/sweetalert/dist/sweetalert.css">
		<!-- Custom CSS -->
		<link href="css/style.css" rel="stylesheet">
		<!-- color CSS -->
		<link href="css/colors/default.css" id="theme"  rel="stylesheet">
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	
	<body>
		<!-- Preloader -->
		<div class="preloader">
		  <div class="cssload-speeding-wheel"></div>
		</div>
		<section id="wrapper">
		  <div class="login-box">
			<div class="white-box">
				<?php if(!empty($errorMessage)){
					echo '<script>setTimeout(function() {
															swal({
																title: "Good job!",
																text: "'.$errorMessage.'",
																type: "success"
															}, function() {
																window.location = "/";
															});
														}, 200);
						</script>';
				}
														?>

			  <form class="form-horizontal form-material" id="setupForm" action="setup.php" method="POST">
				<h3 class="box-title m-b-20">Database Informations:</h3>
				<div class="form-group">
				  <div class="col-xs-12">
					<input class="form-control" type="text" required="" placeholder="Database Host" name="mysql_host">
				  </div>
				</div>
				<div class="form-group ">
				  <div class="col-xs-12">
					<input class="form-control" type="text" required="" placeholder="MySql Username" name="mysql_username">
				  </div>
				</div>
				<div class="form-group">
				  <div class="col-xs-12">
					<input class="form-control" type="password" placeholder="MySql Password" name="mysql_password">
				  </div>
				</div>
				<div class="form-group">
				  <div class="col-xs-12">
					<input class="form-control" type="text" required="" placeholder="Database Name" name="mysql_db">
				  </div>
				</div>
				<hr>
				<h3 class="box-title m-b-20">Login Informations:</h3>
				<div class="form-group ">
				  <div class="col-xs-12">
					<input class="form-control" type="text" required="" placeholder="Username" name="Username">
				  </div>
				</div>
				<div class="form-group">
				  <div class="col-xs-12">
					<input class="form-control" type="password" required="" placeholder="Password" name="Password">
				  </div>
				</div>
				<div class="form-group text-center m-t-20">
				  <div class="col-xs-12">
					<button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Save Settings</button>
				  </div>
				</div>
			  </form>

			</div>
		  </div>
		</section>
		<!-- jQuery -->
		<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap Core JavaScript -->
		<script src="bootstrap/dist/js/tether.min.js"></script>
			<script src="bootstrap/dist/js/bootstrap.min.js"></script>
			<script src="plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
		<!-- Menu Plugin JavaScript -->
		<script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>

		<!--slimscroll JavaScript -->
		<script src="js/jquery.slimscroll.js"></script>
		<!--Wave Effects -->
		<script src="js/waves.js"></script>
		<!-- Custom Theme JavaScript -->
		<script src="js/custom.min.js"></script>
		<!--Style Switcher -->
		<script src="plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
	</body>
</html>