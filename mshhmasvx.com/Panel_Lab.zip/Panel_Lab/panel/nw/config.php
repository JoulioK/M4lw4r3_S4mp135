<?php
$db_host = 'localhost';
$db_username = 'root';
$db_database = 'bpanel';
$db_password = 'root';

$panel_username = 'admin';
$panel_password = 'admin';
?>