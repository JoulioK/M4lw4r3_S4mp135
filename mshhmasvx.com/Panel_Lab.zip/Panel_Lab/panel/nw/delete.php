<?php
require("config.php");
require("mysql.php");

if(isset($_POST['id'])){
	if($_SERVER['PHP_AUTH_USER'] == $panel_username && $_SERVER['PHP_AUTH_PW'] == $panel_password){
		$answer = $base->query("DELETE FROM `users` WHERE id  =".$_POST['id']." LIMIT 1");
		$row = $answer->fetchAll();
		header("Location: index.php?page=".$_GET['page']);
	}
}

?>