<?php
require("mysql.php");
require("config.php");

if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="My Realm"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Error, please auth';
    exit;
} else {
	if($_SERVER['PHP_AUTH_USER'] == $panel_username && $_SERVER['PHP_AUTH_PW'] == $panel_password){
		?>
<link href="https://bootswatch.com/4/solar/bootstrap.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>

<div class="container">
	<div class="row">
    <div class="col-xl-12">
	<br><br>
    <h4>Info</h4>
	<br>
    <div class="table-responsive">
	<table id="mytable" class="table table-bordred table-striped">
            <thead>
                   <th>Id</th>
                   <th>Hwid</th>
                   <th>Country</th>
                   <th>Time</th>
                   <th>Windows Version</th>
                   <th>Delete Log</th>
            </thead>
    <tbody>
    
	<?php
		$answer = $base->query("SELECT * FROM `users`");
		$row = $answer->fetchAll();

		$output="";
		
		if(isset($_GET['page'])){	
			$page = $_GET['page'];
		}else{
			$page = 1;
		}
		
		$pages = (int)(count($row)/64)+1;
		
		$q = 1;
			
		for($i = 64*($page-1)+64; $i>=64*($page-1); $i--){
		
			if(!isset($row[$i]['id'])){
				continue;
			}
			
			$output .= '<tr>
			<td>'.$q++.'</td>
			<td>'.$row[$i]['hwid'].'</td>
			<td>'.$row[$i]['country'].'</td>
			<td>'.$row[$i]['time'].'</td>
			<td>'.$row[$i]['winver'].'</td>
			
			<td>
				<form action="delete.php?page='.$page.'" method="POST">
				<button type="submit" name="id" value="'.$row[$i]['id'].'" style="
				background: transparent;
				border: none !important;
				outline:none; ">
				<img src="./img/trash.png"/>
				</button>
				
			</form>
			</td>
			
			</tr>';
						}
				   ?>
			<?=$output?>	   
		</tbody>
			</table>
				<div class="clearfix"></div>
				<ul class="pagination pull-right">
				  <li class="disabled"><a href="#"><span class="glyphicon glyphicon-chevron-left"></span></a></li>
				  
				  <?php
					$outpu="";
					for($i = 1; $i < $pages+1; $i++){
						
						if($page == $i){
							$outpu.= '<li class="active"><a href="index.php?page='.$i.'"><h5>'.$i.'</h5></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</li>';
						}else{
							$outpu.= '<li><a href="index.php?page='.$i.'"><h5>'.$i.'</h5></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</li>';
						}
						
					}
				  ?>
				  
				<?=$outpu?>
				  
				  <li><a href="#"><span class="glyphicon glyphicon-chevron-right"></span></a></li>
				</ul>
            </div>
        </div>
	</div>
</div>
		<?php
	}else{
		echo 'Wrong username or password.';
	}
}
?>