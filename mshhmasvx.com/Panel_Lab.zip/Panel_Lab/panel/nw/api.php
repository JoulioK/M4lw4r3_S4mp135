<?php
require("mysql.php");

$param = ['country' => $_POST['country'], 'hwid' => $_POST['hwid'], 'time' => date("d/m/Y H:i"), 'winver' => $_POST['winver']];

$query = $base->prepare("INSERT INTO `users` (country, hwid, time, winver) VALUES (:country, :hwid, :time, :winver)");
$query->execute($param); 

?>