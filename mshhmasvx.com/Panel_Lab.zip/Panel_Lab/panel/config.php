<?php
$db_host = '';
$db_username = '';
$db_database = '';
$db_password = '';

$panel_username = 'admin';
$panel_password = 'admin';
?>