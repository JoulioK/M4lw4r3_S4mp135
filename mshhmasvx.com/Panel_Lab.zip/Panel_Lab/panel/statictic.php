<?php
require("mysql.php");
error_reporting(0);
if(isset($_POST['id'])){
	if($_SERVER['PHP_AUTH_USER'] == $panel_username && $_SERVER['PHP_AUTH_PW'] == $panel_password){
		$answer = $base->query("DELETE FROM `users` WHERE id  =".$_POST['id']." LIMIT 1");
		$row = $answer->fetchAll();
		header("Location: index.php?page=".$_GET['page']);
	}
}

$answer = $base->query("SELECT SUM(`amount`) FROM country");
$row = $answer->fetchAll();

$answer = $base->query("SELECT * FROM country");
$row = $answer->fetchAll();

$output;
for($i = 0; $i < count($row); $i++){
	$output = $output. "['". $row[$i][0] ."', ".$row[$i][1]."],";
}

print_r(is_numeric(231));

$output = substr_replace($output, "", -1);
?>

<html>
 <head>
  <meta charset="utf-8">
  <title>Статистика</title>
  <link href="https://bootswatch.com/4/yeti/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="bootstrap.css" rel="stylesheet" id="bootstrap-css">
  <script src="https://www.google.com/jsapi"></script>
  <script>
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
    var data = google.visualization.arrayToDataTable([
	['Страны', 'Количество'],
     <?=$output?>
    ]);
    var options = {
     title: 'Статистика Стран',
	 height: 1100,
	 width: 1000
    };
    var chart = new google.visualization.PieChart(document.getElementById('air'));
     chart.draw(data, options);
   }
  </script>
 </head>
 <body>
 
<div class="sidenav">
  <a href="index.php">Log</a>
  <a href="statictic.php">Statistic</a>
  <a href="loader.php">Loader</a>
</div>

<div class="main" id="air" style="width: 1000px; height: 1000px; margin-top: -180px;"></div>
  
 </body>
</html>
