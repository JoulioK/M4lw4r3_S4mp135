<?php
require("mysql.php");

if($_SERVER['PHP_AUTH_USER'] == $panel_username && $_SERVER['PHP_AUTH_PW'] == $panel_password){
	if(!empty($_POST)){
		$answer = $base->query("UPDATE `loader` SET `loader`='".htmlspecialchars($_POST['loader'])."'");
		$answer->fetchAll();
	}
	$asnw = $base->query("SELECT * FROM `loader`")->fetchAll();
	
}

?>

<html>
 <head>
  <meta charset="utf-8">
  <title>Лоадер</title>
  <link href="https://bootswatch.com/4/superhero/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link href="bootstrap.css" rel="stylesheet" id="bootstrap-css">
 </head>
 <body>
 
<div class="sidenav">
  <a href="index.php">Log</a>
  <a href="statictic.php">Statistic</a>
  <a href="loader.php">Loader</a>
</div>

<div class="main">

	<form name="test" method="POST" action="loader.php">
	
	<input type="text" name="loader" class="form-control">
	<button type="submit" class="btn btn-primary" style="margin-top: 20px;">Submit</button>
	
	</form>
	
</div>
  
 </body>
</html>