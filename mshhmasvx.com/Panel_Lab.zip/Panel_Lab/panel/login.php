<html><head>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!------ Include the above in your HEAD tag ---------->

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700&amp;amp;subset=cyrillic" rel="stylesheet">

</head>

<span id="warning-container"></span>
<body style="background: #eeeeee;"><section>

<div style="position: absolute;top: 35%;left: 50%;margin-top: -60px;margin-left: -130px;width: 500px;height: 500px;">

 <div class="row">
  <div>
	<h2>Please sign in</h2>
		
     <form action="login.php" method="POST" class="login-form">
			
       <input type="text" class="form-control" placeholder="Username" required name="name">
       <input type="password" class="form-control" placeholder="Password" required name="pass">
	   <input class="btn btn-primary" style="margin-top:12px;width:325px;height:40px" type="submit" value="Sign in">
      
     </form>
	 
  </div>
 </div>

</div></section></body></html>

<?php

require("mysql.php");
require("config.php");

$log = $_POST['name'];
$pass = $panel_password;

session_start();

if(isset($_SESSION["session_username"])){
	
	header("Location: index.php");
}

if((isset($pass) && isset($log)) && ($pass === $_POST['pass'] && $log === $panel_username)){

	$_SESSION['session_username']=htmlspecialchars($log);
	header("location: index.php");

}else{
	//header("location: index.php");
}

?>